//#region src/archive/validation.ts
function e(e) {
	throw Error(e);
}
function t(t) {
	return (!t || typeof t != "object" || Array.isArray(t)) && e("Invalid Trace record."), t;
}
function n(t, n) {
	return (typeof t != "string" || t.length > n) && e("Invalid or oversized Trace text."), t;
}
function r(t) {
	let r = n(t, 640);
	return (!r || /[\u0000-\u001f\u007f]/u.test(r)) && e("Invalid Trace identifier."), r;
}
function i(t) {
	return typeof t != "boolean" && e("Invalid Trace flag."), t;
}
function a(t, n = 2 ** 53 - 1) {
	return (typeof t != "number" || !Number.isSafeInteger(t) || t < 0 || t > n) && e("Invalid Trace number."), t;
}
function o(e) {
	return a(e, 864e13);
}
function s(t, n, r) {
	return (!Array.isArray(t) || t.length > n) && e("Invalid or oversized Trace list."), t.map(r);
}
function c(t, n) {
	return n.includes(t) || e("Unsupported Trace value."), t;
}
function l(e, t) {
	return e === void 0 ? void 0 : t(e);
}
function u(e, t) {
	return e === null ? null : t(e);
}
function d(t) {
	return t !== 30 && t !== 90 && t !== "forever" && e("Unsupported retention policy."), t;
}
function f(e) {
	let r = t(e);
	return {
		state: c(r.state, [
			"unknown",
			"partial",
			"complete"
		]),
		reason: n(r.reason, 512)
	};
}
function p(t) {
	let r = n(t, 2048);
	if (!r) return "";
	let i;
	try {
		i = new URL(r);
	} catch {
		return e("Unsupported source conversation URL.");
	}
	return (i.protocol !== "https:" || !["chatgpt.com", "chat.openai.com"].includes(i.hostname) || i.username || i.password || i.port || !/^\/(?:c\/[A-Za-z0-9_-]+|g\/[A-Za-z0-9_-]+\/c\/[A-Za-z0-9_-]+)?\/?$/u.test(i.pathname)) && e("Unsupported source conversation URL."), i.origin + i.pathname;
}
function m(e, i) {
	let a = t(e);
	return {
		value: i(a.value),
		sourceField: n(a.sourceField, 256),
		sourceKind: c(a.sourceKind, [
			"server-reported",
			"dom-observed",
			"local",
			"derived"
		]),
		observedAt: o(a.observedAt),
		replyId: l(a.replyId, r),
		adapterVersion: r(a.adapterVersion),
		endpoint: n(a.endpoint, 128),
		status: c(a.status, [
			"reported",
			"observed",
			"derived"
		])
	};
}
function h(e) {
	if (e === void 0) return;
	let s = t(e), u = (e) => m(e, a), d = (e) => m(e, (e) => n(e, 256));
	return {
		state: c(s.state, [
			"waiting",
			"streaming",
			"reported",
			"partial",
			"unavailable"
		]),
		model: l(s.model, d),
		displayModel: l(s.displayModel, d),
		requestedModel: l(s.requestedModel, d),
		conversationDefault: l(s.conversationDefault, d),
		input: l(s.input, u),
		output: l(s.output, u),
		effectiveWindow: l(s.effectiveWindow, u),
		catalogMaximum: l(s.catalogMaximum, u),
		comparable: i(s.comparable),
		comparableReason: l(s.comparableReason, (e) => n(e, 512)),
		quotas: [],
		observedAt: l(s.observedAt, o),
		replyId: l(s.replyId, r),
		adapterVersion: r(s.adapterVersion)
	};
}
function g(a, d) {
	let m = t(a), g = s(m.messages, 8192, (e) => {
		let a = t(e);
		return {
			id: r(a.id),
			parentId: l(a.parentId, (e) => u(e, r)),
			provisional: i(a.provisional),
			role: c(a.role, ["user", "assistant"]),
			text: n(a.text, 512 * 1024),
			observedAt: o(a.observedAt),
			final: i(a.final),
			activity: d ? h(a.activity) : void 0
		};
	});
	new Set(g.map((e) => e.id)).size !== g.length && e("Duplicate message in this capture.");
	let _ = {
		providerId: r(m.providerId),
		title: n(m.title, 1024),
		sourceUrl: p(m.sourceUrl),
		selectionId: r(m.selectionId),
		leafId: l(m.leafId, r),
		source: c(m.source, ["dom", "history"]),
		messages: g,
		coverage: f(m.coverage),
		observedAt: o(m.observedAt),
		adapterVersion: r(m.adapterVersion),
		batchId: r(m.batchId),
		aliasFrom: l(m.aliasFrom, r)
	}, v = d ? 2097152 : 131072;
	return new TextEncoder().encode(JSON.stringify(_)).byteLength > v && e("Capture exceeds the Trace size limit."), _;
}
function _(e) {
	let r = t(e);
	return {
		label: r.label === void 0 ? "" : n(r.label, 256),
		tags: r.tags === void 0 ? [] : s(r.tags, 32, (e) => n(e, 128)),
		note: r.note === void 0 ? "" : n(r.note, 65536)
	};
}
function v(t, n) {
	return new Set(t.map(n)).size !== t.length && e("Duplicate identity in the Trace file."), t;
}
function y(e) {
	let i = t(e);
	return {
		id: r(i.id),
		label: n(i.label, 128),
		retention: d(i.retention)
	};
}
function b(i) {
	let a = t(i), s = o(a.firstObservedAt), c = o(a.lastObservedAt);
	return s > c && e("Invalid conversation capture interval."), {
		id: r(a.id),
		collectionId: r(a.collectionId),
		providerId: r(a.providerId),
		title: n(a.title, 1024),
		sourceUrl: p(a.sourceUrl),
		firstObservedAt: s,
		lastObservedAt: c,
		segmentId: u(a.segmentId, r),
		coverage: f(a.coverage)
	};
}
function x(e) {
	let a = t(e);
	return {
		id: r(a.id),
		conversationId: r(a.conversationId),
		messageId: r(a.messageId),
		role: c(a.role, ["user", "assistant"]),
		text: n(a.text, 512 * 1024),
		provisional: i(a.provisional),
		parentId: l(a.parentId, (e) => u(e, r)),
		source: c(a.source, ["dom", "history"]),
		adapterVersion: r(a.adapterVersion),
		observedAt: o(a.observedAt),
		final: i(a.final),
		activity: h(a.activity)
	};
}
function S(e) {
	let n = t(e);
	return {
		id: r(n.id),
		conversationId: r(n.conversationId),
		selectionId: r(n.selectionId),
		source: c(n.source, ["dom", "history"]),
		leafId: l(n.leafId, r),
		revisions: v(s(n.revisions, 5e4, (e) => {
			let n = t(e);
			return {
				messageId: r(n.messageId),
				revisionId: r(n.revisionId)
			};
		}), (e) => e.messageId),
		coverage: f(n.coverage),
		observedAt: o(n.observedAt),
		adapterVersion: r(n.adapterVersion)
	};
}
function C(e, t) {
	return e.length > 0 && e.at(-1)?.messageId === t && e.every((t, n) => t.final && !t.provisional && t.parentId === (n === 0 ? null : e[n - 1]?.messageId));
}
function ee(n) {
	let i = t(n), a = b(i.conversation), o = v(s(i.aliases, 1024, r), (e) => e), u = v(s(i.revisions, 1e5, x), (e) => e.id), d = v(s(i.segments, 3e4, S), (e) => e.id), p = l(i.sourceCoverage, f), m = l(i.selection, (e) => c(e, ["branch", "excerpts"]));
	(!o.includes(a.providerId) || a.segmentId !== null && !d.some((e) => e.id === a.segmentId)) && e("Invalid conversation identity or selection.");
	let h = new Map(u.map((e) => [e.id, e])), g = /* @__PURE__ */ new Map();
	for (let t of u) {
		(t.conversationId !== a.id || t.parentId === t.messageId) && e("Invalid revision scope.");
		let n = g.get(t.messageId);
		n && n !== t.role && e("Conflicting roles for a Trace message."), g.set(t.messageId, t.role);
	}
	for (let t of d) {
		t.conversationId !== a.id && e("Invalid segment scope.");
		let n = t.revisions.map((t) => {
			let n = h.get(t.revisionId);
			return (!n || n.messageId !== t.messageId) && e("Missing segment revision."), n;
		});
		t.coverage.state === "complete" && (t.source !== "history" || !C(n, t.leafId)) && e("Invalid complete branch evidence.");
	}
	let _ = d.find((e) => e.id === a.segmentId);
	return a.coverage.state === "complete" && _?.coverage.state !== "complete" && e("Missing complete branch evidence."), {
		conversation: a,
		aliases: o,
		segments: d,
		revisions: u,
		selection: m,
		sourceCoverage: p
	};
}
function te(i) {
	let a = t(i), s = o(a.createdAt), l = o(a.updatedAt);
	return l < s && e("Invalid saved excerpt interval."), {
		id: r(a.id),
		conversationId: r(a.conversationId),
		collectionId: r(a.collectionId),
		revisionId: r(a.revisionId),
		messageId: r(a.messageId),
		role: c(a.role, ["user", "assistant"]),
		text: n(a.text, 512 * 1024),
		title: n(a.title, 1024),
		sourceUrl: p(a.sourceUrl),
		coverage: f(a.coverage),
		activity: h(a.activity),
		..._(a),
		capturedAt: o(a.capturedAt),
		createdAt: s,
		updatedAt: l
	};
}
function w(e) {
	let a = t(e), s = l(a.unavailable, i);
	return {
		conversationId: l(a.conversationId, r),
		revisionId: l(a.revisionId, r),
		messageId: l(a.messageId, r),
		title: n(a.title, 1024),
		sourceUrl: p(a.sourceUrl),
		role: c(a.role, ["user", "assistant"]),
		text: s ? "" : n(a.text, 512 * 1024),
		coverage: f(a.coverage),
		unavailable: s,
		observedAt: l(a.observedAt, o),
		selectionId: l(a.selectionId, r),
		activity: s ? void 0 : h(a.activity)
	};
}
function ne(i) {
	let l = t(i), u = t(l.notes), d = o(l.createdAt), f = o(l.updatedAt), p = a(l.budget, 1e7);
	(!p || f < d) && e("Invalid handoff draft metadata.");
	let m = (e) => n(e, 256 * 1024), h = {
		id: r(l.id),
		collectionId: r(l.collectionId),
		title: n(l.title, 1024),
		template: c(l.template, [
			"general",
			"codex",
			"research"
		]),
		budget: p,
		notes: {
			goal: m(u.goal),
			currentState: m(u.currentState),
			decisions: m(u.decisions),
			constraints: m(u.constraints),
			references: m(u.references),
			openQuestions: m(u.openQuestions),
			nextSteps: m(u.nextSteps)
		},
		evidence: s(l.evidence, 2048, w),
		createdAt: d,
		updatedAt: f
	};
	return new TextEncoder().encode(JSON.stringify(h)).byteLength > 4 * 1024 * 1024 && e("Handoff draft exceeds the Trace size limit."), h;
}
function re(n) {
	let r = n;
	if (typeof r == "string") {
		(r.length > 67108864 || new TextEncoder().encode(r).byteLength > 67108864) && e("Trace file exceeds the 64 MiB restore limit.");
		try {
			r = JSON.parse(r);
		} catch {
			e("This file is not valid Trace JSON.");
		}
	} else {
		let t;
		try {
			t = JSON.stringify(r);
		} catch {
			e("This file is not valid Trace JSON.");
		}
		(!t || new TextEncoder().encode(t).byteLength > 67108864) && e("Invalid or oversized Trace file.");
	}
	let a = t(r);
	(a.format !== "trace" || a.version !== 1) && e("Unsupported Trace file format or version.");
	let u = c(a.kind, ["backup", "conversation"]), d = v(s(a.collections, 5e3, y), (e) => e.id), f = v(s(a.conversations, 5e4, ee), (e) => e.conversation.id), p = v(s(a.saved, 5e4, te), (e) => e.id), m = v(s(a.drafts, 1e4, ne), (e) => e.id), h = o(a.exportedAt), g = l(a.preferences, (e) => ({ contextAlert: i(t(e).contextAlert) }));
	u === "conversation" && (p.length || m.length || g) && e("A conversation export cannot include archive notes or settings.");
	let _ = new Set(d.map((e) => e.id)), b = /* @__PURE__ */ new Map(), x = /* @__PURE__ */ new Set(), S = /* @__PURE__ */ new Set(), C = /* @__PURE__ */ new Set();
	for (let t of f) {
		let { conversation: n } = t;
		_.has(n.collectionId) || e("Missing source collection."), b.set(n.id, n);
		for (let r of t.aliases) {
			let t = JSON.stringify([n.collectionId, r]);
			x.has(t) && e("Duplicate scoped provider identity."), x.add(t);
		}
		for (let n of t.revisions) S.has(n.id) && e("Duplicate revision identity."), S.add(n.id);
		for (let n of t.segments) C.has(n.id) && e("Duplicate segment identity."), C.add(n.id);
	}
	for (let t of [...p, ...m]) _.has(t.collectionId) || e("Missing source collection.");
	for (let t of p) {
		let n = b.get(t.conversationId);
		n && n.collectionId !== t.collectionId && e("Saved excerpt collection mismatch.");
	}
	return {
		format: "trace",
		version: 1,
		kind: u,
		exportedAt: h,
		collections: d,
		conversations: f,
		saved: p,
		drafts: m,
		preferences: g
	};
}
function ie(e) {
	return {
		kind: e.kind,
		collections: e.collections,
		conversations: e.conversations.length,
		revisions: e.conversations.reduce((e, t) => e + t.revisions.length, 0),
		saved: e.saved.length,
		drafts: e.drafts.length
	};
}
//#endregion
//#region node_modules/idb/build/index.js
var T = (e, t) => t.some((t) => e instanceof t), ae, oe;
function se() {
	return ae ||= [
		IDBDatabase,
		IDBObjectStore,
		IDBIndex,
		IDBCursor,
		IDBTransaction
	];
}
function ce() {
	return oe ||= [
		IDBCursor.prototype.advance,
		IDBCursor.prototype.continue,
		IDBCursor.prototype.continuePrimaryKey
	];
}
var le = /* @__PURE__ */ new WeakMap(), ue = /* @__PURE__ */ new WeakMap(), de = /* @__PURE__ */ new WeakMap();
function fe(e) {
	let t = new Promise((t, n) => {
		let r = () => {
			e.removeEventListener("success", i), e.removeEventListener("error", a);
		}, i = () => {
			t(E(e.result)), r();
		}, a = () => {
			n(e.error), r();
		};
		e.addEventListener("success", i), e.addEventListener("error", a);
	});
	return de.set(t, e), t;
}
function pe(e) {
	if (le.has(e)) return;
	let t = new Promise((t, n) => {
		let r = () => {
			e.removeEventListener("complete", i), e.removeEventListener("error", a), e.removeEventListener("abort", a);
		}, i = () => {
			t(), r();
		}, a = () => {
			n(e.error || new DOMException("AbortError", "AbortError")), r();
		};
		e.addEventListener("complete", i), e.addEventListener("error", a), e.addEventListener("abort", a);
	});
	le.set(e, t);
}
var me = {
	get(e, t, n) {
		if (e instanceof IDBTransaction) {
			if (t === "done") return le.get(e);
			if (t === "store") return n.objectStoreNames[1] ? void 0 : n.objectStore(n.objectStoreNames[0]);
		}
		return E(e[t]);
	},
	set(e, t, n) {
		return e[t] = n, !0;
	},
	has(e, t) {
		return e instanceof IDBTransaction && (t === "done" || t === "store") ? !0 : t in e;
	}
};
function he(e) {
	me = e(me);
}
function ge(e) {
	return ce().includes(e) ? function(...t) {
		return e.apply(ve(this), t), E(this.request);
	} : function(...t) {
		return E(e.apply(ve(this), t));
	};
}
function _e(e) {
	return typeof e == "function" ? ge(e) : (e instanceof IDBTransaction && pe(e), T(e, se()) ? new Proxy(e, me) : e);
}
function E(e) {
	if (e instanceof IDBRequest) return fe(e);
	if (ue.has(e)) return ue.get(e);
	let t = _e(e);
	return t !== e && (ue.set(e, t), de.set(t, e)), t;
}
var ve = (e) => de.get(e);
function ye(e, t, { blocked: n, upgrade: r, blocking: i, terminated: a } = {}) {
	let o = indexedDB.open(e, t), s = E(o);
	return r && o.addEventListener("upgradeneeded", (e) => {
		r(E(o.result), e.oldVersion, e.newVersion, E(o.transaction), e);
	}), n && o.addEventListener("blocked", (e) => n(e.oldVersion, e.newVersion, e)), s.then((e) => {
		a && e.addEventListener("close", () => a()), i && e.addEventListener("versionchange", (e) => i(e.oldVersion, e.newVersion, e));
	}).catch(() => {}), s;
}
var be = [
	"get",
	"getKey",
	"getAll",
	"getAllKeys",
	"count"
], xe = [
	"put",
	"add",
	"delete",
	"clear"
], Se = /* @__PURE__ */ new Map();
function Ce(e, t) {
	if (!(e instanceof IDBDatabase && !(t in e) && typeof t == "string")) return;
	if (Se.get(t)) return Se.get(t);
	let n = t.replace(/FromIndex$/, ""), r = t !== n, i = xe.includes(n);
	if (!(n in (r ? IDBIndex : IDBObjectStore).prototype) || !(i || be.includes(n))) return;
	let a = async function(e, ...t) {
		let a = this.transaction(e, i ? "readwrite" : "readonly"), o = a.store;
		return r && (o = o.index(t.shift())), (await Promise.all([o[n](...t), i && a.done]))[0];
	};
	return Se.set(t, a), a;
}
he((e) => ({
	...e,
	get: (t, n, r) => Ce(t, n) || e.get(t, n, r),
	has: (t, n) => !!Ce(t, n) || e.has(t, n)
}));
var we = [
	"continue",
	"continuePrimaryKey",
	"advance"
], Te = {}, Ee = /* @__PURE__ */ new WeakMap(), De = /* @__PURE__ */ new WeakMap(), Oe = { get(e, t) {
	if (!we.includes(t)) return e[t];
	let n = Te[t];
	return n ||= Te[t] = function(...e) {
		Ee.set(this, De.get(this)[t](...e));
	}, n;
} };
async function* ke(...e) {
	let t = this;
	if (t instanceof IDBCursor || (t = await t.openCursor(...e)), !t) return;
	t = t;
	let n = new Proxy(t, Oe);
	for (De.set(n, t), de.set(n, ve(t)); t;) yield n, t = await (Ee.get(n) || t.continue()), Ee.delete(n);
}
function Ae(e, t) {
	return t === Symbol.asyncIterator && T(e, [
		IDBIndex,
		IDBObjectStore,
		IDBCursor
	]) || t === "iterate" && T(e, [IDBIndex, IDBObjectStore]);
}
he((e) => ({
	...e,
	get(t, n, r) {
		return Ae(t, n) ? ke : e.get(t, n, r);
	},
	has(t, n) {
		return Ae(t, n) || e.has(t, n);
	}
}));
//#endregion
//#region src/archive/database.ts
var je = {
	autoCapture: !1,
	generation: 1,
	contextAlert: !1,
	welcomeComplete: !1
}, Me = "trace-archive", Ne = [
	"meta",
	"collections",
	"fences",
	"aliases",
	"exclusions",
	"conversations",
	"messages",
	"revisions",
	"segments",
	"saved",
	"drafts",
	"receipts",
	"jobs",
	"importPayloads",
	"importMap",
	"importLocks"
], Pe = [
	"conversations",
	"collections",
	"revisions",
	"segments",
	"saved",
	"drafts",
	"aliases",
	"messages"
];
function Fe(e = "trace-archive") {
	return ye(e, 4, {
		blocking(e, t, n) {
			n.target.close();
		},
		upgrade(e, t, n, r) {
			if (t >= 1) {
				if (t < 2) {
					let e = r.objectStore("exclusions");
					e.indexNames.contains("group") || e.createIndex("group", "groupId");
				}
				if (t < 3 && (r.objectStore("revisions").createIndex("message", ["conversationId", "messageId"]), r.objectStore("segments").createIndex("selection", ["conversationId", "selectionId"])), t < 4) for (let e of Pe) r.objectStore(e).createIndex("job", "jobId");
				return;
			}
			e.createObjectStore("meta", { keyPath: "key" }), e.createObjectStore("collections", { keyPath: "id" }).createIndex("scope", "scopeKey", { unique: !0 }), e.createObjectStore("fences", { keyPath: "tabId" }), e.createObjectStore("aliases", { keyPath: ["collectionId", "providerId"] }).createIndex("conversation", "conversationId"), e.createObjectStore("exclusions", { keyPath: ["collectionId", "providerId"] }).createIndex("group", "groupId"), e.createObjectStore("conversations", { keyPath: "id" }).createIndex("collection", "collectionId"), e.createObjectStore("messages", { keyPath: ["conversationId", "id"] }).createIndex("conversation", "conversationId");
			let i = e.createObjectStore("revisions", { keyPath: "id" });
			i.createIndex("conversation", "conversationId"), i.createIndex("message", ["conversationId", "messageId"]);
			let a = e.createObjectStore("segments", { keyPath: "id" });
			a.createIndex("conversation", "conversationId"), a.createIndex("selection", ["conversationId", "selectionId"]);
			let o = e.createObjectStore("saved", { keyPath: "id" });
			o.createIndex("conversation", "conversationId"), o.createIndex("collection", "collectionId"), e.createObjectStore("drafts", { keyPath: "id" }).createIndex("collection", "collectionId");
			let s = e.createObjectStore("receipts", { keyPath: "key" });
			s.createIndex("conversation", "conversationId"), s.createIndex("time", "observedAt"), e.createObjectStore("jobs", { keyPath: "id" }), e.createObjectStore("importPayloads"), e.createObjectStore("importMap"), e.createObjectStore("importLocks", { keyPath: "conversationId" }).createIndex("job", "jobId");
			for (let e of Pe) r.objectStore(e).createIndex("job", "jobId");
		}
	});
}
async function D(e) {
	let t = await e.objectStore("meta").get("settings");
	return t?.key === "settings" ? t.value : { ...je };
}
async function O(e) {
	let t = await e.objectStore("meta").get("revision");
	return t?.key === "revision" ? t.value : {
		number: 0,
		changes: []
	};
}
async function k(e, t = [], n = !1) {
	let r = await O(e), i = r.number + 1, a = {
		revision: i,
		ids: n ? [] : [...new Set(t)],
		reset: n
	};
	return await e.objectStore("meta").put({
		key: "revision",
		value: {
			number: i,
			changes: [...r.changes.slice(-255), a]
		}
	}), i;
}
function Ie(e) {
	if (!(typeof BroadcastChannel > "u")) try {
		let t = new BroadcastChannel(Me);
		t.postMessage({ archiveRevision: e }), t.close();
	} catch {}
}
function A(e, t, n) {
	return t.retention !== "forever" && e.lastObservedAt + t.retention * 864e5 <= n;
}
async function j(e, t) {
	return !!t && (!t.jobId || (await e.objectStore("jobs").get(t.jobId))?.state === "complete");
}
function M(e) {
	let t = { ...e };
	return delete t.jobId, delete t.localOrigin, t;
}
async function N(e, t) {
	let n = [...new Set(t.flatMap((e) => e.jobId ? [e.jobId] : []))], r = await Promise.all(n.map((t) => e.objectStore("jobs").get(t))), i = new Set(r.flatMap((e) => e?.state === "complete" ? [e.id] : []));
	return t.filter((e) => !e.jobId || i.has(e.jobId)).map(M);
}
//#endregion
//#region src/archive/merge.ts
var Le = {
	state: "unknown",
	reason: "The captured text does not establish full branch coverage."
};
async function Re(t, n, r) {
	let i = await t.objectStore("aliases").get([n, r]);
	return i && !await j(t, i) && e("A restore is still importing this conversation."), i;
}
async function ze(t, n, r, i) {
	let a = await Re(t, n, i), o = await Re(t, n, r);
	a && await Je(t, a.conversationId), o && await Je(t, o.conversationId);
	let s = a?.conversationId ?? o?.conversationId, c = t.objectStore("exclusions");
	if ((await Promise.all([c.get([n, i]), c.get([n, r])])).some(Boolean) && await qe(t, n, [i, r], !0), s) {
		if (o && o.conversationId !== s) {
			let n = o.conversationId, r = await t.objectStore("aliases").index("conversation").getAll(n);
			for (let e of r) await t.objectStore("aliases").put({
				...e,
				conversationId: s
			});
			let i = t.objectStore("revisions"), a = /* @__PURE__ */ new Map();
			for (let e of await i.index("conversation").getAll(s)) {
				let t = a.get(e.messageId) ?? [];
				t.push(e), a.set(e.messageId, t);
			}
			let c = /* @__PURE__ */ new Map();
			for (let t of await i.index("conversation").getAll(n)) {
				let n = a.get(t.messageId) ?? [];
				n.some((e) => e.role !== t.role) && e("The proposed aliases have conflicting message roles.");
				let r = n.find((e) => Ve(e, t) && Ve(t, e));
				c.set(t.id, r?.id ?? t.id), r ? await i.delete(t.id) : await i.put({
					...t,
					conversationId: s
				});
			}
			let l = t.objectStore("segments");
			for (let e of await l.index("conversation").getAll(n)) {
				let t = e.revisions.map((e) => ({
					...e,
					revisionId: c.get(e.revisionId) ?? e.revisionId
				}));
				await l.put({
					...e,
					conversationId: s,
					revisions: t
				});
			}
			let u = t.objectStore("saved");
			for (let e of await u.index("conversation").getAll(n)) await u.put({
				...e,
				conversationId: s,
				revisionId: c.get(e.revisionId) ?? e.revisionId
			});
			let d = t.objectStore("receipts");
			for (let e of await d.index("conversation").getAll(n)) await d.put({
				...e,
				conversationId: s
			});
			let f = t.objectStore("messages");
			for (let e of await f.index("conversation").getAll(n)) {
				let r = await f.get([s, e.id]), [i, a] = await Promise.all([r ? t.objectStore("revisions").get(r.currentRevisionId) : void 0, t.objectStore("revisions").get(c.get(e.currentRevisionId) ?? e.currentRevisionId)]);
				(!i || a && (a.observedAt > i.observedAt || a.final && !i.final)) && await f.put({
					...e,
					conversationId: s,
					currentRevisionId: c.get(e.currentRevisionId) ?? e.currentRevisionId
				}), await f.delete([n, e.id]);
			}
			for (let e of await t.objectStore("drafts").getAll()) e.evidence.some((e) => e.conversationId === n) && (e.evidence = e.evidence.map((e) => e.conversationId === n ? {
				...e,
				conversationId: s,
				revisionId: e.revisionId ? c.get(e.revisionId) ?? e.revisionId : void 0
			} : e), await t.objectStore("drafts").put(e));
			let p = t.objectStore("conversations"), [m, h] = await Promise.all([p.get(s), p.get(n)]);
			if (h) {
				let e = m && m.lastObservedAt > h.lastObservedAt ? m : h;
				await p.put({
					...e,
					id: s,
					firstObservedAt: Math.min(m?.firstObservedAt ?? Infinity, h.firstObservedAt)
				});
			}
			await p.delete(n), await k(t, [n, s]);
		}
		return await t.objectStore("aliases").put({
			collectionId: n,
			providerId: r,
			conversationId: s
		}), await t.objectStore("aliases").put({
			collectionId: n,
			providerId: i,
			conversationId: s
		}), s;
	}
}
function Be(e, t) {
	let n = new Map(e.messages.filter((e) => e.provisional).map((e) => [e.id, "provisional:" + t + ":" + e.id]));
	return {
		...e,
		leafId: e.leafId === void 0 ? void 0 : n.get(e.leafId) ?? e.leafId,
		messages: e.messages.map((e) => ({
			...e,
			id: n.get(e.id) ?? e.id,
			parentId: typeof e.parentId == "string" ? n.get(e.parentId) ?? e.parentId : e.parentId
		}))
	};
}
function Ve(e, t) {
	return e.role === t.role && e.text === t.text && e.final === t.final && e.provisional === t.provisional && e.parentId === t.parentId && (!t.activity || JSON.stringify(e.activity) === JSON.stringify(t.activity));
}
async function He(t, n, r, i) {
	let a = t.objectStore("messages"), o = t.objectStore("revisions"), s = await a.get([n, r.id]), c = s && await o.get(s.currentRevisionId);
	c && c.role !== r.role && e("Conflicting roles for a Trace message."), r.parentId === r.id && e("Invalid self-parenting message.");
	let l = {
		id: crypto.randomUUID(),
		conversationId: n,
		messageId: r.id,
		role: r.role,
		text: r.text,
		provisional: r.provisional,
		parentId: r.parentId ?? (r.parentId === null ? null : c?.parentId),
		source: i.source,
		adapterVersion: i.adapterVersion,
		observedAt: r.observedAt,
		final: r.final,
		activity: r.activity
	};
	if (c && Ve(c, l)) return M(c);
	if (await o.add(l), !c || l.final && !c.final || l.final === c.final && l.observedAt >= c.observedAt) {
		let e = {
			conversationId: n,
			id: r.id,
			parentId: l.parentId,
			provisional: l.provisional,
			role: r.role,
			currentRevisionId: l.id
		};
		await a.put(e);
	}
	return l;
}
async function Ue(e, t, n, r) {
	let i = new Map(r.map((e) => [e.messageId, e])), a = /* @__PURE__ */ new Set(), o = [], s = n;
	for (; s && !a.has(s) && o.length < 5e4;) {
		a.add(s);
		let n = i.get(s);
		if (!n) {
			let r = await e.objectStore("messages").get([t, s]), i = r && await e.objectStore("revisions").get(r.currentRevisionId);
			i && await j(e, i) && (n = M(i));
		}
		if (!n) break;
		o.push(n), s = n.parentId;
	}
	return o.reverse();
}
function We(e) {
	return JSON.stringify([
		e.source,
		e.leafId,
		e.coverage,
		e.revisions
	]);
}
function Ge(e, t, n, r, i) {
	let a = t.source === "history" && C(r, t.leafId) && t.messages.every((e, n) => e.final && !e.provisional && e.parentId === (n === 0 ? null : t.messages[n - 1]?.id)) && r.length === n.length && r.every((e, t) => e.id === n[t]?.id), o = t.coverage;
	i ? o = {
		state: "partial",
		reason: "Selected messages from the observed branch or segment."
	} : o.state === "complete" && !a && (o = {
		state: "partial",
		reason: "The observed revisions do not prove a finalized branch from its root."
	}), o.state === "unknown" && t.source === "history" && !a && (o = {
		state: "partial",
		reason: "Only part of the branch was observed."
	});
	let s = (r.length ? r : n).map((e) => ({
		messageId: e.messageId,
		revisionId: e.id
	}));
	return {
		id: crypto.randomUUID(),
		conversationId: e,
		selectionId: t.selectionId,
		source: t.source,
		leafId: i ? void 0 : t.leafId,
		revisions: s,
		coverage: o,
		observedAt: t.observedAt,
		adapterVersion: t.adapterVersion
	};
}
function Ke(e, t, n, r) {
	return {
		id: crypto.randomUUID(),
		conversationId: e.id,
		collectionId: e.collectionId,
		revisionId: t.id,
		messageId: t.messageId,
		role: t.role,
		text: t.text,
		title: e.title,
		sourceUrl: e.sourceUrl,
		coverage: e.coverage,
		activity: t.activity,
		..._(n),
		capturedAt: t.observedAt,
		createdAt: r,
		updatedAt: r
	};
}
async function qe(e, t, n, r) {
	let i = e.objectStore("exclusions"), a = new Set(n), o = /* @__PURE__ */ new Set();
	for (let e of a) {
		let n = await i.get([t, e]);
		n?.groupId && o.add(n.groupId);
	}
	for (let e of o) for (let n of await i.index("group").getAll(e)) n.collectionId === t && a.add(n.providerId);
	let s = a.size > 1 ? o.values().next().value ?? crypto.randomUUID() : void 0;
	for (let e of a) r ? await i.put({
		collectionId: t,
		providerId: e,
		groupId: s
	}) : await i.delete([t, e]);
}
async function Je(t, n) {
	await t.objectStore("importLocks").get(n) && e("A restore is still importing this conversation.");
}
async function Ye(t, n, r, i, a, o, s, c) {
	let l = t.objectStore("receipts"), u = await l.get(a);
	if (u) return { result: {
		conversationId: u.conversationId,
		segmentId: u.segmentId,
		savedIds: u.savedIds,
		duplicate: !0
	} };
	let d = s && new Set(s);
	d?.size && (!r.messages.some((e) => d.has(e.id)) || r.messages.filter((e) => d.has(e.id)).length !== d.size) && e("The reviewed selection changed."), d && !d.size && e("Select at least one message."), r.messages.length || e("No supported messages were observed.");
	let f = Be({
		...r,
		messages: d ? r.messages.filter((e) => d.has(e.id)) : r.messages
	}, i), p = await Re(t, n.id, f.providerId), m = f.aliasFrom && f.aliasFrom !== f.providerId ? f.aliasFrom : void 0, h = m ? await ze(t, n.id, f.providerId, m) : p?.conversationId, g = h ?? crypto.randomUUID();
	h && await Je(t, g);
	let _ = t.objectStore("conversations"), v = await _.get(g);
	v && A(v, n, o) && (await Xe(t, g), v = void 0), await t.objectStore("aliases").put({
		collectionId: n.id,
		providerId: f.providerId,
		conversationId: g
	}), m && await t.objectStore("aliases").put({
		collectionId: n.id,
		providerId: m,
		conversationId: g
	});
	let y = [];
	for (let e of f.messages) y.push(await He(t, g, e, f));
	let b = Ge(g, f, y, !d && f.source === "history" && f.leafId ? await Ue(t, g, f.leafId, y) : [], !!d), x = t.objectStore("segments"), S = await x.index("conversation").getAll(g), C = await N(t, S), ee = new Set(S.filter((e) => e.localOrigin === i).map((e) => e.id)), te = C.find((e) => ee.has(e.id) && e.selectionId === b.selectionId && We(e) === We(b)), w = te ?? b;
	te || await x.add({
		...b,
		localOrigin: i
	});
	let ne = new Set(w.revisions.map((e) => e.revisionId));
	for (let e of y) {
		if (ne.has(e.id) || C.some((t) => t.revisions.some((t) => t.revisionId === e.id))) continue;
		let t = {
			id: crypto.randomUUID(),
			conversationId: g,
			source: f.source,
			selectionId: f.selectionId,
			coverage: {
				state: "unknown",
				reason: "This observed revision could not be placed on the selected branch."
			},
			observedAt: f.observedAt,
			adapterVersion: f.adapterVersion,
			revisions: [{
				messageId: e.messageId,
				revisionId: e.id
			}]
		};
		await x.add({
			...t,
			localOrigin: i
		});
	}
	let re = C.find((e) => e.id === v?.segmentId), ie = !v || f.observedAt >= v.lastObservedAt && (re?.coverage.state !== "complete" || w.coverage.state === "complete" || re.leafId !== w.leafId), T = v && v.providerId !== f.providerId && !m ? v : void 0, ae = {
		id: g,
		collectionId: n.id,
		providerId: T ? T.providerId : f.providerId,
		title: f.title || v?.title || "Untitled conversation",
		sourceUrl: T ? T.sourceUrl : f.sourceUrl || v?.sourceUrl || "",
		firstObservedAt: Math.min(v?.firstObservedAt ?? o, Math.min(f.observedAt, o)),
		lastObservedAt: Math.max(v?.lastObservedAt ?? 0, Math.min(f.observedAt, o)),
		segmentId: ie ? w.id : v?.segmentId ?? null,
		coverage: ie ? w.coverage : v?.coverage ?? Le
	};
	await _.put(ae);
	let oe = [];
	if (c) for (let e of y) {
		let n = Ke({
			...ae,
			coverage: w.coverage
		}, e, c, o);
		await t.objectStore("saved").add(n), oe.push(n.id);
	}
	let se = {
		conversationId: g,
		segmentId: w.id,
		savedIds: oe,
		duplicate: !1
	};
	return await l.put({
		key: a,
		conversationId: g,
		segmentId: w.id,
		savedIds: oe,
		observedAt: o
	}), {
		result: se,
		archiveRevision: await k(t, [g])
	};
}
async function Xe(e, t) {
	for (let n of [
		"revisions",
		"segments",
		"messages",
		"receipts"
	]) {
		let r = e.objectStore(n);
		for (let e of await r.index("conversation").getAllKeys(t)) await r.delete(e);
	}
	await e.objectStore("conversations").delete(t);
}
//#endregion
//#region src/archive/read.ts
async function P(e, t) {
	let n = await e.objectStore("collections").get(t);
	return n && await j(e, n) ? M(n) : void 0;
}
async function Ze(e) {
	return N(e, await e.objectStore("collections").getAll());
}
async function Qe(e, t, n) {
	let r = new Map((await Ze(e)).map((e) => [e.id, e])), i = e.objectStore("conversations");
	return (await N(e, n === void 0 ? await i.getAll() : await i.index("collection").getAll(n))).filter((e) => {
		let n = r.get(e.collectionId);
		return n && !A(e, n, t);
	}).sort((e, t) => t.lastObservedAt - e.lastObservedAt);
}
async function $e(e, t) {
	let n = e.objectStore("saved");
	return N(e, t === void 0 ? await n.getAll() : await n.index("collection").getAll(t));
}
async function et(e, t, n, r) {
	let i = e.objectStore("conversations"), [a, o] = await Promise.all([i.get(t), e.objectStore("saved").index("conversation").getAll(t).then((t) => N(e, t))]), s = a && await j(e, a) ? M(a) : void 0, c = s?.collectionId ?? o.at(0)?.collectionId;
	if (!c) return;
	let l = await P(e, c);
	if (!l) return;
	let u = !s || A(s, l, n), d = o.at(0);
	if (u && !d) return;
	let f = s ?? {
		id: t,
		collectionId: c,
		providerId: "",
		title: d.title,
		sourceUrl: d.sourceUrl,
		firstObservedAt: d.capturedAt,
		lastObservedAt: d.capturedAt,
		segmentId: null,
		coverage: d.coverage
	}, p = u ? [] : await N(e, await e.objectStore("segments").index("conversation").getAll(t));
	p.sort((e, t) => t.observedAt - e.observedAt);
	let m = r ?? f.segmentId, h = p.find((e) => e.id === m) ?? (r === void 0 ? p.at(0) : void 0) ?? null, g = [];
	if (h) {
		let n = e.objectStore("revisions"), r = await N(e, (await Promise.all(h.revisions.map((e) => n.get(e.revisionId)))).filter((e) => e !== void 0));
		g.push(...r.filter((e) => e.conversationId === t));
	}
	return {
		conversation: f,
		collection: l,
		segments: p,
		segment: h,
		messages: g,
		saved: o,
		expired: u
	};
}
function tt(e) {
	return {
		id: "s:" + e.id,
		conversationId: e.conversationId,
		collectionId: e.collectionId,
		title: e.title,
		text: e.text,
		tags: e.tags,
		note: e.note,
		role: e.role,
		reportedModel: e.activity?.model?.value ?? null,
		capturedAt: e.capturedAt,
		updatedAt: e.updatedAt,
		saved: !0,
		coverage: e.coverage,
		revisionId: e.revisionId,
		savedId: e.id
	};
}
async function nt(e, t, n) {
	let r = await e.objectStore("conversations").get(t);
	if (!r || !await j(e, r)) return;
	let i = await P(e, r.collectionId);
	if (!i || A(r, i, n)) return;
	let a = await N(e, await e.objectStore("segments").index("conversation").getAll(t));
	a.sort((e, t) => Number(t.id === r.segmentId) - Number(e.id === r.segmentId) || t.observedAt - e.observedAt);
	let o = /* @__PURE__ */ new Map();
	for (let e of a) for (let t of e.revisions) o.has(t.revisionId) || o.set(t.revisionId, e);
	return {
		conversation: r,
		segmentByRevision: o
	};
}
function rt(e, t) {
	let { conversation: n } = t, r = t.segmentByRevision.get(e.id);
	return {
		id: "r:" + e.id,
		conversationId: n.id,
		collectionId: n.collectionId,
		title: n.title,
		text: e.text,
		tags: [],
		note: "",
		role: e.role,
		reportedModel: e.activity?.model?.value ?? null,
		capturedAt: e.observedAt,
		updatedAt: n.lastObservedAt,
		saved: !1,
		coverage: r?.coverage ?? {
			state: "unknown",
			reason: "No selected segment contains this revision."
		},
		segmentId: r?.id,
		revisionId: e.id
	};
}
async function it(e, t, n, r) {
	let i = (await O(e)).number, a = [], o = /* @__PURE__ */ new Map(), s = null, c = 0, l = Math.max(r * 2, 32);
	if (!n?.startsWith("s:")) {
		let u = await e.objectStore("revisions").openCursor(n?.startsWith("r:") ? IDBKeyRange.lowerBound(n.slice(2), !0) : void 0);
		for (; u;) {
			let n = u.value;
			if (await j(e, n)) {
				let r = o.get(n.conversationId);
				r || (r = nt(e, n.conversationId, t), o.set(n.conversationId, r));
				let i = await r;
				i && a.push(rt(n, i));
			}
			if (s = "r:" + u.primaryKey, c++, a.length >= r || c >= l) return {
				archiveRevision: i,
				next: s,
				documents: a
			};
			u = await u.continue();
		}
	}
	let u = await e.objectStore("saved").openCursor(n?.startsWith("s:") ? IDBKeyRange.lowerBound(n.slice(2), !0) : void 0);
	for (; u;) {
		if (await j(e, u.value) && a.push(tt(u.value)), s = "s:" + u.primaryKey, c++, a.length >= r || c >= l) return {
			archiveRevision: i,
			next: s,
			documents: a
		};
		u = await u.continue();
	}
	return {
		archiveRevision: i,
		next: null,
		documents: a
	};
}
async function at(e, t, n, r) {
	let i = (await O(e)).number, a = /* @__PURE__ */ new Map(), o = [];
	for (let i of n) if (i.startsWith("s:")) {
		let t = await e.objectStore("saved").get(i.slice(2));
		t && (r === void 0 || t.collectionId === r) && await j(e, t) && o.push(tt(t));
	} else if (i.startsWith("r:")) {
		let n = await e.objectStore("revisions").get(i.slice(2));
		if (!n || !await j(e, n)) continue;
		let s = a.get(n.conversationId);
		s || (s = nt(e, n.conversationId, t), a.set(n.conversationId, s));
		let c = await s;
		c && (r === void 0 || c.conversation.collectionId === r) && o.push(rt(n, c));
	}
	return {
		archiveRevision: i,
		documents: o
	};
}
async function ot(e, t, n, r) {
	let i = (await O(e)).number, a = [];
	for (let i of n) {
		let n = await nt(e, i, t);
		if (n && (r === void 0 || n.conversation.collectionId === r)) for (let t of await N(e, await e.objectStore("revisions").index("conversation").getAll(i))) a.push(rt(t, n));
		for (let t of await N(e, await e.objectStore("saved").index("conversation").getAll(i))) (r === void 0 || t.collectionId === r) && a.push(tt(t));
	}
	return {
		archiveRevision: i,
		documents: a
	};
}
//#endregion
//#region src/archive/restore.ts
function st(e) {
	return {
		id: e.id,
		state: e.state,
		processed: e.processed,
		total: e.total,
		createdAt: e.createdAt,
		error: e.error
	};
}
async function ct(e) {
	return (await e.objectStore("jobs").getAll()).sort((e, t) => t.createdAt - e.createdAt).map(st);
}
async function lt(e, t, n) {
	let i = n && new Set(n.map(r)), a = (await Ze(e)).filter((e) => !i || i.has(e.id)).map(({ id: e, label: t, retention: n }) => ({
		id: e,
		label: t,
		retention: n
	})), o = new Set(a.map(({ id: e }) => e)), s = (await Qe(e, t)).filter((e) => o.has(e.collectionId)), c = [];
	for (let t of s) {
		let [n, r, i] = await Promise.all([
			e.objectStore("aliases").index("conversation").getAll(t.id).then((t) => N(e, t)),
			e.objectStore("segments").index("conversation").getAll(t.id).then((t) => N(e, t)),
			e.objectStore("revisions").index("conversation").getAll(t.id).then((t) => N(e, t))
		]);
		c.push({
			conversation: t,
			aliases: [...new Set([t.providerId, ...n.map((e) => e.providerId)])],
			segments: r,
			revisions: i
		});
	}
	return {
		format: "trace",
		version: 1,
		kind: "backup",
		exportedAt: t,
		collections: a,
		conversations: c,
		saved: (await $e(e)).filter((e) => o.has(e.collectionId)),
		drafts: (await N(e, await e.objectStore("drafts").getAll())).filter((e) => o.has(e.collectionId)),
		preferences: { contextAlert: (await D(e)).contextAlert }
	};
}
function ut(e) {
	let { conversation: t, aliases: n, revisions: r, segments: i } = e, a = [{
		kind: "prepare",
		record: {
			conversation: t,
			aliases: n
		}
	}], o = [], s = 0;
	for (let e of r) o.push(e), s += e.text.length, (o.length === 96 || s >= 384 * 1024) && (a.push({
		kind: "revisions",
		conversationId: t.id,
		records: o
	}), o = [], s = 0);
	o.length && a.push({
		kind: "revisions",
		conversationId: t.id,
		records: o
	});
	for (let e = 0; e < i.length; e += 8) a.push({
		kind: "segments",
		conversationId: t.id,
		records: i.slice(e, e + 8)
	});
	return a.push({
		kind: "finish",
		conversationId: t.id,
		segmentId: t.segmentId
	}), a;
}
async function dt(t, n, i, a) {
	a !== void 0 && !await P(t, r(a)) && e("Destination collection unavailable.");
	let o = t.objectStore("jobs");
	(await o.getAll()).some((e) => e.state !== "complete") && e("Finish or remove the incomplete restore before starting another.");
	let s = [
		...n.collections.map((e) => ({
			kind: "collection",
			record: e
		})),
		...n.conversations.flatMap(ut),
		...n.saved.map((e) => ({
			kind: "saved",
			record: e
		})),
		...n.drafts.map((e) => ({
			kind: "draft",
			record: e
		}))
	], c = {
		id: crypto.randomUUID(),
		state: "pending",
		processed: 0,
		total: s.length,
		createdAt: i,
		destinationId: a,
		contextAlert: n.preferences?.contextAlert
	};
	await o.add(c);
	let l = t.objectStore("importPayloads");
	return await Promise.all(s.map((e, t) => l.add(e, [c.id, t]))), st(c);
}
function F(e, t, n, r) {
	return e.objectStore("importMap").get([
		t.id,
		n,
		r
	]);
}
function I(e, t, n, r, i) {
	return e.objectStore("importMap").put(i, [
		t.id,
		n,
		r
	]);
}
async function ft(t, n, r) {
	if (n.destinationId) {
		await P(t, n.destinationId) || e("Destination collection unavailable."), await I(t, n, "collection", r.id, n.destinationId);
		return;
	}
	let i = r.id.startsWith("restored:") ? r.id : "restored:" + r.id, a = t.objectStore("collections");
	await a.get(i) || await a.add({
		id: i,
		label: r.label,
		retention: r.retention,
		mode: "manual",
		autoExcluded: !1,
		autoConsent: !1,
		createdAt: n.createdAt,
		jobId: n.id
	}), await I(t, n, "collection", r.id, i);
}
async function pt(t, n, r) {
	let i = t.objectStore("importLocks"), a = await i.get(r);
	a && a.jobId !== n.id && e("Another restore is already using this conversation."), a || await i.add({
		conversationId: r,
		jobId: n.id
	});
}
async function mt(t, n, r) {
	let i = r.conversation, a = await F(t, n, "collection", i.collectionId) ?? e("Missing import collection."), o = i.sourceUrl.match(/\/c\/([A-Za-z0-9_-]+)\/?$/u)?.[1] === i.providerId && !i.providerId.startsWith("local:"), s = o ? i.providerId : "local:" + crypto.randomUUID(), c = o ? r.aliases.filter((e) => !e.startsWith("local:")) : [s], l = t.objectStore("aliases"), u = (await Promise.all(c.map((e) => l.get([a, e])))).filter((e) => e !== void 0);
	new Set(u.map((e) => e.conversationId)).size > 1 && e("Imported aliases refer to different saved conversations.");
	let d = u.at(0)?.conversationId ?? crypto.randomUUID();
	await pt(t, n, d), await I(t, n, "conversation", i.id, d);
	let f = t.objectStore("conversations");
	await f.get(d) || await f.add({
		...i,
		id: d,
		collectionId: a,
		providerId: s,
		segmentId: null,
		jobId: n.id
	});
	for (let e of c) u.some((t) => t.providerId === e) || await l.add({
		collectionId: a,
		providerId: e,
		conversationId: d,
		jobId: n.id
	});
}
async function ht(t, n, r, i) {
	let a = await F(t, n, "conversation", r) ?? e("Missing import conversation."), o = t.objectStore("revisions"), s = t.objectStore("messages");
	for (let r of i) {
		let i = await o.index("message").getAll([a, r.messageId]), c = [];
		for (let e of i) (e.jobId === n.id || await j(t, e)) && c.push(e);
		c.some((e) => e.role !== r.role) && e("A restored message conflicts with the existing message role.");
		let l = {
			...r,
			conversationId: a
		}, u = c.find((e) => Ve(e, l));
		if (u) {
			await I(t, n, "revision", r.id, u.id);
			continue;
		}
		await o.get(l.id) && (l.id = crypto.randomUUID()), await o.add({
			...l,
			jobId: n.id
		}), await I(t, n, "revision", r.id, l.id);
		let d = await s.get([a, l.messageId]), f = d?.jobId === n.id && await o.get(d.currentRevisionId);
		if (!d || f && (l.final && !f.final || l.final === f.final && l.observedAt >= f.observedAt)) {
			let e = {
				conversationId: a,
				id: l.messageId,
				parentId: l.parentId,
				role: l.role,
				provisional: l.provisional,
				currentRevisionId: l.id
			};
			await s.put({
				...e,
				jobId: n.id
			});
		}
	}
}
async function gt(t, n, r, i) {
	let a = await F(t, n, "conversation", r) ?? e("Missing import conversation."), o = t.objectStore("segments");
	for (let r of i) {
		let i = await Promise.all(r.revisions.map(async (r) => ({
			...r,
			revisionId: await F(t, n, "revision", r.revisionId) ?? e("Missing imported revision.")
		}))), s = await o.index("selection").getAll([a, r.selectionId]), c = JSON.stringify(i), l = s.find((e) => e.source === r.source && e.leafId === r.leafId && e.coverage.state === r.coverage.state && JSON.stringify(e.revisions) === c), u = l?.id ?? (await o.get(r.id) ? crypto.randomUUID() : r.id);
		await I(t, n, "segment", r.id, u), l || await o.add({
			...r,
			revisions: i,
			id: u,
			conversationId: a,
			jobId: n.id
		});
	}
}
async function _t(t, n, r, i) {
	let a = await F(t, n, "conversation", r) ?? e("Missing import conversation."), o = t.objectStore("conversations"), s = await o.get(a) ?? e("Missing import conversation.");
	if (s.jobId === n.id) {
		let r = i ? await F(t, n, "segment", i) ?? e("Missing imported selection.") : null;
		await o.put({
			...s,
			segmentId: r
		});
	}
}
async function vt(t, n, r) {
	let i = await F(t, n, "collection", r.collectionId) ?? e("Missing import collection."), a = await F(t, n, "conversation", r.conversationId), o = r.sourceUrl.match(/\/c\/([A-Za-z0-9_-]+)\/?$/u)?.[1], s = o ? await t.objectStore("aliases").get([i, o]) : void 0;
	if (a ??= s?.conversationId, !a) {
		let e = await t.objectStore("saved").get(r.id);
		a = e?.collectionId === i && e.sourceUrl === r.sourceUrl ? e.conversationId : crypto.randomUUID();
	}
	await pt(t, n, a), await I(t, n, "conversation", r.conversationId, a);
	let c = await F(t, n, "revision", r.revisionId) ?? r.revisionId, l = {
		...r,
		conversationId: a,
		collectionId: i,
		revisionId: c
	}, u = t.objectStore("saved"), d = await u.get(r.id);
	if ((await u.index("conversation").getAll(a)).some((e) => e.revisionId === c && e.text === l.text && e.note === l.note && JSON.stringify(e.tags) === JSON.stringify(l.tags) && (e.label === l.label || e.label === yt(l.label)))) return;
	let f = d ? crypto.randomUUID() : r.id;
	await u.add({
		...l,
		id: f,
		label: d ? yt(l.label) : l.label,
		jobId: n.id
	});
}
function yt(e) {
	return e.slice(0, 240) + (e ? " (imported)" : "Imported copy");
}
async function bt(t, n, r) {
	let i = await F(t, n, "collection", r.collectionId) ?? e("Missing import collection."), a = [];
	for (let e of r.evidence) {
		let r = e.conversationId ? await F(t, n, "conversation", e.conversationId) : void 0, i = e.revisionId ? await F(t, n, "revision", e.revisionId) ?? e.revisionId : void 0;
		a.push({
			...e,
			conversationId: r,
			revisionId: i
		});
	}
	let o = t.objectStore("drafts"), s = await o.get(r.id);
	if ((await o.index("collection").getAll(i)).some((e) => (e.title === r.title || e.title === yt(r.title)) && e.budget === r.budget && e.template === r.template && JSON.stringify(e.notes) === JSON.stringify(r.notes) && JSON.stringify(e.evidence) === JSON.stringify(a))) return;
	let c = s ? crypto.randomUUID() : r.id;
	await o.add({
		...r,
		evidence: a,
		collectionId: i,
		id: c,
		title: s ? yt(r.title) : r.title,
		jobId: n.id
	});
}
async function xt(e, t) {
	await e.objectStore("importPayloads").delete(IDBKeyRange.bound([t], [t, []])), await e.objectStore("importMap").delete(IDBKeyRange.bound([t], [t, []]));
	let n = e.objectStore("importLocks");
	for (let e of await n.index("job").getAllKeys(t)) await n.delete(e);
}
async function St(t, n, r) {
	let i = t.objectStore("jobs"), a = await i.get(n) ?? e("Restore job unavailable.");
	if (a.state === "complete") return { value: st(a) };
	let o = t.objectStore("importPayloads"), s = a.processed;
	a.state = "pending", a.error = void 0;
	for (let r = s; r < Math.min(a.total, s + 8); r++) {
		let i = await o.get([n, r]) ?? e("Missing restore checkpoint.");
		switch (i.kind) {
			case "collection":
				await ft(t, a, i.record);
				break;
			case "conversation":
				await mt(t, a, i.record), await ht(t, a, i.record.conversation.id, i.record.revisions), await gt(t, a, i.record.conversation.id, i.record.segments), await _t(t, a, i.record.conversation.id, i.record.conversation.segmentId);
				break;
			case "prepare":
				await mt(t, a, i.record);
				break;
			case "revisions":
				await ht(t, a, i.conversationId, i.records);
				break;
			case "segments":
				await gt(t, a, i.conversationId, i.records);
				break;
			case "finish":
				await _t(t, a, i.conversationId, i.segmentId);
				break;
			case "saved":
				await vt(t, a, i.record);
				break;
			case "draft":
				await bt(t, a, i.record);
				break;
		}
		if (await o.delete([n, r]), a.processed++, i.kind === "revisions" && i.records.length >= 96) break;
	}
	let c;
	if (a.processed === a.total) {
		if (a.state = "complete", a.contextAlert !== void 0) {
			let e = await D(t);
			await t.objectStore("meta").put({
				key: "settings",
				value: {
					...e,
					contextAlert: a.contextAlert
				}
			});
		}
		await xt(t, n), c = await k(t, [], !0);
	}
	return await i.put(a), {
		value: st(a),
		archiveRevision: c
	};
}
async function Ct(t, n) {
	let r = t.objectStore("jobs"), i = await r.get(n);
	if (!i) return { value: void 0 };
	i.state === "complete" && e("Only incomplete restores can be removed.");
	for (let e of Pe) {
		let r = t.objectStore(e);
		for (let e of await r.index("job").getAllKeys(n)) await r.delete(e);
	}
	return await xt(t, n), await r.delete(n), { value: void 0 };
}
//#endregion
//#region src/archive/repository.ts
var wt = /^local:[a-f0-9-]{36}$/iu;
function Tt(t) {
	return n(t, 128).trim() || e("Enter a collection name.");
}
async function L(e, t) {
	let n = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(e + "\0" + t));
	return Array.from(new Uint8Array(n), (e) => e.toString(16).padStart(2, "0")).join("");
}
function Et(e) {
	return a(e.tabId), a(e.epoch), L("document", r(e.documentId));
}
function Dt(t) {
	if (t.aliasFrom !== void 0) return (!wt.test(t.aliasFrom) || wt.test(t.providerId) || !t.sourceUrl.replace(/\/$/u, "").endsWith("/c/" + t.providerId)) && e("Unverified temporary conversation alias."), t.aliasFrom;
}
async function Ot(e, t, n, i) {
	let [a, o, s, c, l] = await Promise.all([
		Et(e),
		e.collectionId ? L("collection", r(e.collectionId)) : void 0,
		t ? L("provider", JSON.stringify([e.documentId, r(t)])) : void 0,
		n ? L("selection", JSON.stringify([e.documentId, r(n)])) : void 0,
		i ? L("provider", JSON.stringify([e.documentId, r(i)])) : void 0
	]);
	return {
		documentHash: a,
		collectionHash: o,
		providerHash: s,
		selectionHash: c,
		aliasHash: l
	};
}
function kt(e, t, n) {
	return e?.epoch === t.epoch && e.documentHash === n;
}
function At(e) {
	return e.match(/\/c\/([A-Za-z0-9_-]+)\/?$/u)?.[1];
}
var jt = class {
	constructor(e, t = Date.now) {
		this.db = e, this.clock = t;
	}
	close() {
		this.db.close();
	}
	async read(e) {
		let t = this.db.transaction(Ne, "readonly"), n = t.done.catch(() => void 0);
		try {
			return await e(t);
		} finally {
			await n;
		}
	}
	async write(e) {
		let t = this.db.transaction(Ne, "readwrite"), n = t.done;
		n.catch(() => void 0);
		try {
			let r = await e(t);
			return await n, r.archiveRevision !== void 0 && Ie(r.archiveRevision), r.value;
		} catch (e) {
			try {
				t.abort();
			} catch {}
			throw await n.catch(() => void 0), e;
		}
	}
	getSettings() {
		return this.read(D);
	}
	setSettings(e) {
		return t(e), this.write(async (t) => {
			let n = await D(t), r = e.autoCapture === void 0 ? n.autoCapture : i(e.autoCapture), a = {
				autoCapture: r,
				contextAlert: e.contextAlert === void 0 ? n.contextAlert : i(e.contextAlert),
				welcomeComplete: e.welcomeComplete === void 0 ? n.welcomeComplete : i(e.welcomeComplete),
				generation: n.generation + Number(r !== n.autoCapture)
			};
			return await t.objectStore("meta").put({
				key: "settings",
				value: a
			}), { value: a };
		});
	}
	listCollections() {
		return this.read(Ze);
	}
	createCollection(n) {
		t(n);
		let i = n.mode === void 0 ? "manual" : c(n.mode, ["manual", "observed"]), a = i === "observed" && n.scopeKey !== void 0 ? r(n.scopeKey) : void 0, o = Tt(n.label), s = n.retention === void 0 ? 90 : d(n.retention);
		return this.write(async (t) => {
			let n = t.objectStore("collections");
			a && await n.index("scope").get(a) && e("That observed account already has a collection.");
			let r = {
				id: crypto.randomUUID(),
				label: o,
				mode: i,
				scopeKey: a,
				retention: s,
				autoConsent: !1,
				autoExcluded: !1,
				createdAt: this.clock()
			};
			return await n.add(r), {
				value: r,
				archiveRevision: await k(t)
			};
		});
	}
	updateCollection(n, a) {
		return r(n), t(a), this.write(async (t) => {
			let r = await P(t, n) ?? e("Collection unavailable."), o = {
				...r,
				label: a.label === void 0 ? r.label : Tt(a.label),
				retention: a.retention === void 0 ? r.retention : d(a.retention),
				autoExcluded: a.autoExcluded === void 0 ? r.autoExcluded : i(a.autoExcluded),
				autoConsent: a.autoConsent === void 0 ? r.autoConsent : i(a.autoConsent)
			};
			if (r.autoExcluded !== o.autoExcluded || r.autoConsent !== o.autoConsent) {
				let e = await D(t);
				await t.objectStore("meta").put({
					key: "settings",
					value: {
						...e,
						generation: e.generation + 1
					}
				});
			}
			return await t.objectStore("collections").put(o), {
				value: o,
				archiveRevision: await k(t, [], r.retention !== o.retention)
			};
		});
	}
	resolveObservedCollection(e) {
		return r(e), this.read(async (t) => {
			let n = await t.objectStore("collections").index("scope").get(e);
			return n && await j(t, n) ? M(n) : void 0;
		});
	}
	async bindObservedCollection(t, n) {
		r(t), r(n);
		let i = await L("collection", t);
		return this.write(async (r) => {
			let a = await P(r, t) ?? e("Collection unavailable.");
			if (a.scopeKey === n) return { value: a };
			a.scopeKey && e("This collection is already bound to a different observed account."), await r.objectStore("collections").index("scope").get(n) && e("That observed account already has a collection.");
			let [o, s, c, l] = await Promise.all([
				r.objectStore("conversations").index("collection").count(t),
				r.objectStore("aliases").count(IDBKeyRange.bound([t], [t, []])),
				r.objectStore("saved").index("collection").count(t),
				r.objectStore("drafts").index("collection").count(t)
			]);
			(o || s || c || l) && e("Choose an empty collection for an observed account.");
			let u = {
				...a,
				mode: "observed",
				scopeKey: n,
				autoConsent: !1
			};
			await r.objectStore("collections").put(u);
			let d = await D(r);
			await r.objectStore("meta").put({
				key: "settings",
				value: {
					...d,
					generation: d.generation + 1
				}
			});
			let f = r.objectStore("fences");
			for (let e of await f.getAll()) e.collectionHash === i && await f.delete(e.tabId);
			return {
				value: u,
				archiveRevision: await k(r)
			};
		});
	}
	async setBinding(t) {
		let n = await Ot(t, t.providerId, t.selectionId);
		await this.write(async (r) => {
			if (t.collectionId) {
				let n = await P(r, t.collectionId) ?? e("Collection unavailable.");
				n.mode === "observed" && (!n.scopeKey || t.scopeKey !== n.scopeKey) && e("Observed account binding does not match this collection.");
			}
			let i = r.objectStore("fences"), a = await i.get(t.tabId);
			return a?.documentHash === n.documentHash && a.epoch > t.epoch && e("This conversation view has changed."), await i.put({
				tabId: t.tabId,
				epoch: t.epoch,
				ordinary: t.ordinary === !0,
				documentHash: n.documentHash,
				collectionHash: n.collectionHash,
				providerHash: n.providerHash,
				selectionHash: n.selectionHash
			}), { value: void 0 };
		});
	}
	async removeBinding(e, t, n) {
		let i = await L("document", r(e));
		a(t), await this.write(async (e) => {
			let r = e.objectStore("fences"), a = n === void 0 ? await r.getAll() : [await r.get(n)];
			for (let e of a) e?.documentHash === i && e.epoch <= t && await r.delete(e.tabId);
			return { value: void 0 };
		});
	}
	removeTabBinding(e) {
		return this.write(async (t) => (await t.objectStore("fences").delete(a(e)), { value: void 0 }));
	}
	resetFences() {
		return this.write(async (e) => (await e.objectStore("fences").clear(), { value: void 0 }));
	}
	async getCaptureStatus(e, t) {
		let n = await Ot(e, t);
		return this.read(async (r) => {
			let [i, a, o, s] = await Promise.all([
				D(r),
				r.objectStore("fences").get(e.tabId),
				e.collectionId ? P(r, e.collectionId) : void 0,
				e.collectionId && t ? r.objectStore("exclusions").get([e.collectionId, t]) : void 0
			]), c = !!o && kt(a, e, n.documentHash) && !!a?.collectionHash && a.collectionHash === n.collectionHash, l = !!s || !!(o && (o.autoExcluded || !o.autoConsent)) || !!(a?.providerHash && n.providerHash !== a.providerHash) || !a?.ordinary;
			return {
				enabled: i.autoCapture && c && !l,
				generation: i.generation,
				bound: c,
				paused: l
			};
		});
	}
	async capture(t, n) {
		let r = g(t, !1), i = Dt(r), o = await Ot(n, r.providerId, void 0, i);
		a(n.generation);
		try {
			return await this.write(async (t) => {
				let [a, s, c] = await Promise.all([
					D(t),
					t.objectStore("fences").get(n.tabId),
					P(t, n.collectionId)
				]);
				(!a.autoCapture || a.generation !== n.generation || !c?.autoConsent || c.autoExcluded || !s?.ordinary || !kt(s, n, o.documentHash) || s.collectionHash !== o.collectionHash || !s.providerHash || s.providerHash !== o.providerHash && s.providerHash !== o.aliasHash) && e("Automatic saving is paused or the conversation view changed.");
				let l = t.objectStore("exclusions"), [u, d] = await Promise.all([l.get([c.id, r.providerId]), i ? l.get([c.id, i]) : void 0]);
				if (u || d) return i && await qe(t, c.id, [r.providerId, i], !0), { value: null };
				let f = JSON.stringify([
					"auto",
					o.documentHash,
					n.epoch,
					n.generation,
					r.batchId
				]), p = await Ye(t, c, r, o.documentHash.slice(0, 32) + ":" + n.epoch, f, this.clock());
				return {
					value: p.result,
					archiveRevision: p.archiveRevision
				};
			}) ?? e("Automatic saving is paused for this chat.");
		} catch (t) {
			throw t instanceof DOMException && t.name === "QuotaExceededError" && (await this.setSettings({ autoCapture: !1 }).catch(() => void 0), e("Local storage is full. Automatic saving is paused.")), t;
		}
	}
	async saveCapture(t, n, i, o) {
		let c = g(t, !0), l = Dt(c), u = await Ot(n, c.providerId, c.selectionId, l);
		a(n.generation), a(n.expiresAt);
		let d = r(n.intentId), f = i && s(i, 8192, r), p = o === void 0 ? void 0 : _(o);
		return this.write(async (t) => {
			let [r, i, a] = await Promise.all([
				D(t),
				t.objectStore("fences").get(n.tabId),
				P(t, n.collectionId)
			]), o = this.clock();
			(!i?.providerHash || !i.selectionHash || !kt(i, n, u.documentHash) || !a || r.generation !== n.generation || n.expiresAt <= o || n.expiresAt > o + 15 * 6e4 || i.providerHash !== u.providerHash && i.providerHash !== u.aliasHash || i.selectionHash !== u.selectionHash) && e("This save review expired or the conversation view changed.");
			let s = JSON.stringify(["explicit", d]), l = await Ye(t, a, c, u.documentHash.slice(0, 32) + ":" + n.epoch, s, o, f, p);
			return {
				value: l.result,
				archiveRevision: l.archiveRevision
			};
		});
	}
	listConversations(e) {
		return this.read((t) => Qe(t, this.clock(), e ?? void 0));
	}
	getConversation(e, t) {
		return this.read((n) => et(n, r(e), this.clock(), t ?? void 0));
	}
	lookupConversation(e, t) {
		return this.read(async (n) => {
			let i = await n.objectStore("aliases").get([r(e), r(t)]);
			if (!i || !await j(n, i)) return;
			let a = await n.objectStore("conversations").get(i.conversationId), o = await P(n, e);
			return a && o && await j(n, a) && !A(a, o, this.clock()) ? M(a) : void 0;
		});
	}
	getArchiveRevision() {
		return this.read(async (e) => (await O(e)).number);
	}
	searchPage(e, t = 150) {
		return this.read((n) => it(n, this.clock(), e ?? void 0, Math.max(1, a(t, 500))));
	}
	hydrateSearch(e, t) {
		let n = s(e, 500, r);
		return this.read((e) => at(e, this.clock(), n, t));
	}
	searchConversations(e, t) {
		let n = s(e, 1024, r);
		return this.read((e) => ot(e, this.clock(), n, t));
	}
	searchChanges(e) {
		return a(e), this.read(async (t) => {
			let n = await O(t), r = n.changes.filter((t) => t.revision > e), i = e > n.number || r.length > 0 && r[0].revision > e + 1 || r.some((e) => e.reset);
			return {
				archiveRevision: n.number,
				reset: i,
				conversationIds: i ? [] : [...new Set(r.flatMap((e) => e.ids))]
			};
		});
	}
	listSaved(e) {
		return this.read(async (t) => (await $e(t, e ?? void 0)).sort((e, t) => t.updatedAt - e.updatedAt));
	}
	saveMessage(n) {
		t(n);
		let i = _(n);
		return this.write(async (t) => {
			let a = r(n.conversationId), [o, s] = await Promise.all([et(t, a, this.clock()), t.objectStore("revisions").get(r(n.revisionId))]);
			(!o || o.expired || !s || s.conversationId !== a || !await j(t, s)) && e("This source revision is no longer available.");
			let c = o.segments.find((e) => e.revisions.some((e) => e.revisionId === s.id)), l = Ke({
				...o.conversation,
				coverage: c?.coverage ?? o.conversation.coverage
			}, s, i, this.clock());
			return await t.objectStore("saved").add(l), {
				value: l,
				archiveRevision: await k(t, [a])
			};
		});
	}
	updateSaved(n, i) {
		return t(i), this.write(async (t) => {
			let a = t.objectStore("saved"), o = await a.get(r(n));
			(!o || !await j(t, o)) && e("Saved excerpt unavailable.");
			let s = _({
				label: i.label ?? o.label,
				tags: i.tags ?? o.tags,
				note: i.note ?? o.note
			}), c = {
				...M(o),
				...s,
				updatedAt: Math.max(o.createdAt, this.clock())
			};
			return await a.put(c), {
				value: c,
				archiveRevision: await k(t, [o.conversationId])
			};
		});
	}
	deleteSaved(e) {
		return this.write(async (t) => {
			let n = t.objectStore("saved"), i = await n.get(r(e));
			return !i || !await j(t, i) ? { value: void 0 } : (await n.delete(e), {
				value: void 0,
				archiveRevision: await k(t, [i.conversationId])
			});
		});
	}
	listDrafts(e) {
		return this.read(async (t) => {
			let n = t.objectStore("drafts");
			return (await N(t, e == null ? await n.getAll() : await n.index("collection").getAll(e))).sort((e, t) => t.updatedAt - e.updatedAt);
		});
	}
	saveDraft(t) {
		let n = ne(t);
		return this.write(async (t) => {
			await P(t, n.collectionId) || e("Collection unavailable.");
			let r = t.objectStore("drafts"), i = await r.get(n.id);
			i && (!await j(t, i) || i.collectionId !== n.collectionId) && e("Handoff is unavailable in this collection.");
			for (let e of n.evidence) {
				let r = At(e.sourceUrl), i = r && await t.objectStore("aliases").get([n.collectionId, r]);
				if (!e.conversationId && i && await j(t, i) && (e.conversationId = i.conversationId), e.conversationId && !await t.objectStore("conversations").get(e.conversationId)) {
					let n = await t.objectStore("saved").index("conversation").getKey(e.conversationId), r = await t.objectStore("aliases").index("conversation").getKey(e.conversationId);
					!n && !r && (e.text = "", e.activity = void 0, e.unavailable = !0);
				}
			}
			return await r.put(n), {
				value: n,
				archiveRevision: await k(t)
			};
		});
	}
	deleteDraft(e) {
		return this.write(async (t) => {
			let n = t.objectStore("drafts"), i = await n.get(r(e));
			return !i || !await j(t, i) ? { value: void 0 } : (await n.delete(e), {
				value: void 0,
				archiveRevision: await k(t)
			});
		});
	}
	isProviderExcluded(e, t) {
		return this.read(async (n) => !!await n.objectStore("exclusions").get([r(e), r(t)]));
	}
	setProviderExcluded(t, n, a) {
		return r(t), r(n), i(a), this.write(async (r) => {
			await P(r, t) || e("Collection unavailable.");
			let i = r.objectStore("aliases"), o = await i.get([t, n]), s = o ? await i.index("conversation").getAll(o.conversationId) : [];
			return await this.applyExclusion(r, t, [n, ...s.map((e) => e.providerId)], a), { value: void 0 };
		});
	}
	setConversationExcluded(t, n) {
		return r(t), i(n), this.write(async (r) => {
			let i = await r.objectStore("aliases").index("conversation").getAll(t);
			return i.length || e("Conversation unavailable."), await this.applyExclusion(r, i[0].collectionId, i.map((e) => e.providerId), n), { value: void 0 };
		});
	}
	async applyExclusion(e, t, n, r) {
		await qe(e, t, n, r);
		let i = await D(e);
		await e.objectStore("meta").put({
			key: "settings",
			value: {
				...i,
				generation: i.generation + 1
			}
		});
	}
	deleteConversation(e) {
		return r(e), this.write(async (t) => {
			await Je(t, e);
			let n = await t.objectStore("aliases").index("conversation").getAll(e), r = t.objectStore("saved"), i = await r.index("conversation").getAll(e), a = (await t.objectStore("conversations").get(e))?.collectionId ?? n[0]?.collectionId ?? i[0]?.collectionId;
			if (!a) return { value: void 0 };
			let o = new Set(n.map((e) => e.providerId));
			for (let e of i) {
				let t = At(e.sourceUrl);
				t && o.add(t), await r.delete(e.id);
			}
			await this.applyExclusion(t, a, [...o], !0);
			let s = t.objectStore("aliases");
			for (let e of n) await s.delete([a, e.providerId]);
			await Xe(t, e);
			let c = t.objectStore("drafts");
			for (let t of await c.getAll()) {
				let n = !1;
				t.evidence = t.evidence.map((r) => r.conversationId === e || !r.conversationId && t.collectionId === a && o.has(At(r.sourceUrl) ?? "") ? (n = !0, {
					...r,
					text: "",
					activity: void 0,
					unavailable: !0
				}) : r), n && await c.put(t);
			}
			return {
				value: void 0,
				archiveRevision: await k(t, [e])
			};
		});
	}
	async storageStatus() {
		let e = await this.read(async (e) => {
			let [t, n, r, i] = await Promise.all([
				Qe(e, this.clock()),
				$e(e),
				e.objectStore("drafts").getAll().then((t) => N(e, t)),
				e.objectStore("conversations").getAll().then((t) => N(e, t))
			]);
			return {
				conversations: t.length,
				saved: n.length,
				drafts: r.length,
				pendingCleanup: i.length - t.length
			};
		}), t = typeof navigator > "u" ? void 0 : await navigator.storage?.estimate().catch(() => void 0);
		return {
			...e,
			bytes: t?.usage,
			quota: t?.quota
		};
	}
	cleanup() {
		return this.write(async (e) => {
			let t = this.clock(), n = new Map((await Ze(e)).map((e) => [e.id, e])), r = (await N(e, await e.objectStore("conversations").getAll())).filter((e) => {
				let r = n.get(e.collectionId);
				return r && A(e, r, t);
			}), i = r.length ? await N(e, await e.objectStore("drafts").getAll()) : [], a = new Set(i.flatMap((e) => e.evidence.flatMap((e) => e.conversationId ? [e.conversationId] : []))), o = [], s = e.objectStore("aliases");
			for (let t of r) if (!await e.objectStore("importLocks").get(t.id)) {
				if (await Xe(e, t.id), !a.has(t.id) && !await e.objectStore("saved").index("conversation").getKey(t.id)) for (let e of await s.index("conversation").getAllKeys(t.id)) await s.delete(e);
				if (o.push(t.id), o.length >= 24) break;
			}
			let c = e.objectStore("receipts"), l = await c.index("time").getAllKeys(IDBKeyRange.upperBound(t - 7 * 864e5), 128);
			for (let e of l) await c.delete(e);
			return {
				value: o.length,
				archiveRevision: o.length ? await k(e, o) : void 0
			};
		});
	}
	clearAll() {
		return this.write(async (e) => {
			let t = await D(e);
			for (let t of Ne) t !== "meta" && await e.objectStore(t).clear();
			return await e.objectStore("meta").put({
				key: "settings",
				value: {
					...je,
					generation: t.generation + 1
				}
			}), {
				value: void 0,
				archiveRevision: await k(e, [], !0)
			};
		});
	}
	makeBackup(e) {
		return this.read((t) => lt(t, this.clock(), e));
	}
	async previewImport(e) {
		return ie(re(e));
	}
	startImport(e, t) {
		let n = re(e);
		return this.write(async (e) => ({ value: await dt(e, n, this.clock(), t ?? void 0) }));
	}
	resumeImport(e) {
		let t = r(e);
		return this.write(async (e) => await St(e, t, this.clock())).catch(async (e) => this.write(async (n) => {
			let r = n.objectStore("jobs"), i = await r.get(t);
			if (!i || i.state === "complete") throw e;
			return i.state = "failed", i.error = e instanceof Error ? e.message : "Restore could not continue.", await r.put(i), { value: await ct(n).then((e) => e.find((e) => e.id === i.id)) };
		}));
	}
	listJobs() {
		return this.read(ct);
	}
	removeImport(e) {
		return this.write(async (t) => await Ct(t, r(e)));
	}
};
async function Mt(e, t) {
	return new jt(await Fe(e), t);
}
//#endregion
//#region src/product.ts
var R = {
	name: "Trace",
	version: "0.1.0",
	origin: "https://chatgpt.com"
}, Nt = 900 * 1e3, Pt = (e) => new TextEncoder().encode(JSON.stringify(e)).length, z = (e, t) => typeof e == "string" && e.length > 0 && e.length <= t, B = (e) => !!e && typeof e == "object" && !Array.isArray(e), V = (e) => z(e, 256) && !/[\u0000-\u001f\u007f]/.test(e);
function Ft(e) {
	return B(e) && Number.isSafeInteger(e.epoch) && Number(e.epoch) >= 0 && V(e.providerId) && V(e.selectionId);
}
function H(e, t) {
	return !!e && !!t && e.epoch === t.epoch && e.providerId === t.providerId && e.selectionId === t.selectionId;
}
function It(e) {
	if (typeof e != "string") return null;
	try {
		let t = new URL(e);
		return t.origin !== R.origin || t.username || t.password ? null : /^\/(?:g\/[A-Za-z0-9_-]+\/)?c\/([A-Za-z0-9_-]{1,160})\/?$/.exec(t.pathname)?.[1] ?? null;
	} catch {
		return null;
	}
}
function Lt(e, t) {
	if (It(e) === t) return !0;
	if (typeof e != "string" || typeof t != "string" || !/^local:[0-9a-f-]{36}$/i.test(t)) return !1;
	try {
		let t = new URL(e);
		return t.origin === R.origin && !t.username && !t.password && (/^\/$/.test(t.pathname) || /^\/g\/[a-zA-Z0-9_-]+\/?$/.test(t.pathname));
	} catch {
		return !1;
	}
}
function Rt(e) {
	if (e.id !== chrome.runtime.id || !e.url || (e.frameId ?? 0) !== 0 || e.tab?.incognito || e.documentLifecycle && e.documentLifecycle !== "active") return null;
	try {
		let t = new URL(e.url);
		return e.origin && e.origin !== t.origin && e.origin !== "chrome-extension://" + chrome.runtime.id ? null : t.origin === R.origin && e.tab?.id !== void 0 && e.documentId ? "content" : t.protocol !== "chrome-extension:" || t.hostname !== chrome.runtime.id ? null : t.pathname === "/library.html" ? "library" : t.pathname === "/popup.html" ? "popup" : null;
	} catch {
		return null;
	}
}
var zt = [
	"model",
	"displayModel",
	"requestedModel",
	"conversationDefault",
	"accountDefault",
	"input",
	"output",
	"effectiveWindow",
	"catalogMaximum"
], Bt = [
	"remaining",
	"used",
	"total",
	"resetSeconds",
	"deadline"
], U = (e) => Number.isSafeInteger(e) && Number(e) >= 0;
function Vt(e, t) {
	return B(e) && Object.keys(e).every((e) => [
		"value",
		"status",
		"sourceKind",
		"sourceField",
		"observedAt",
		"replyId",
		"adapterVersion",
		"endpoint"
	].includes(e)) && (t ? z(e.value, 256) : Number.isSafeInteger(e.value) && Number(e.value) >= 0) && [
		"reported",
		"observed",
		"derived"
	].includes(String(e.status)) && [
		"server-reported",
		"dom-observed",
		"local",
		"derived"
	].includes(String(e.sourceKind)) && z(e.sourceField, 256) && z(e.endpoint, 96) && z(e.adapterVersion, 64) && U(e.observedAt) && (!e.replyId || V(e.replyId));
}
function Ht(e) {
	return !B(e) || !Object.keys(e).every((e) => [
		...zt,
		"state",
		"replyId",
		"comparable",
		"comparableReason",
		"quotas",
		"observedAt",
		"adapterVersion"
	].includes(e)) || ![
		"waiting",
		"streaming",
		"reported",
		"partial",
		"unavailable"
	].includes(String(e.state)) || typeof e.comparable != "boolean" || !z(e.adapterVersion, 64) || e.replyId !== void 0 && !V(e.replyId) || e.observedAt !== void 0 && !U(e.observedAt) || e.comparableReason !== void 0 && !z(e.comparableReason, 256) || !Array.isArray(e.quotas) || e.quotas.length > 64 ? !1 : zt.every((t, n) => e[t] === void 0 || Vt(e[t], n < 5)) && e.quotas.every((e) => B(e) && z(e.feature, 128) && z(e.scope, 256) && U(e.observedAt) && Object.keys(e).every((e) => [
		"feature",
		"scope",
		"observedAt",
		...Bt
	].includes(e)) && Bt.every((t) => e[t] === void 0 || Vt(e[t], !1)));
}
function Ut(e) {
	return B(e) && Object.keys(e).every((e) => [
		"id",
		"parentId",
		"provisional",
		"role",
		"text",
		"observedAt",
		"final",
		"activity"
	].includes(e)) && V(e.id) && (e.parentId == null || V(e.parentId)) && typeof e.provisional == "boolean" && (e.role === "user" || e.role === "assistant") && typeof e.text == "string" && new TextEncoder().encode(e.text).length <= 512 * 1024 && typeof e.final == "boolean" && U(e.observedAt) && (e.activity === void 0 || Ht(e.activity));
}
function Wt(e, t, n) {
	return !B(e) || !Object.keys(e).every((e) => [
		"providerId",
		"title",
		"sourceUrl",
		"selectionId",
		"leafId",
		"source",
		"messages",
		"coverage",
		"observedAt",
		"adapterVersion",
		"batchId",
		"aliasFrom"
	].includes(e)) || e.providerId !== t.providerId || e.selectionId !== t.selectionId || !Lt(e.sourceUrl, t.providerId) || typeof e.title != "string" || e.title.length > 1024 || !V(e.batchId) || !z(e.adapterVersion, 64) || !U(e.observedAt) || !["dom", "history"].includes(String(e.source)) || !B(e.coverage) || !Object.keys(e.coverage).every((e) => e === "state" || e === "reason") || ![
		"complete",
		"unknown",
		"partial"
	].includes(String(e.coverage.state)) || !z(e.coverage.reason, 1024) || !Array.isArray(e.messages) || !e.messages.length || e.messages.length > 4096 || e.leafId !== void 0 && !V(e.leafId) || e.aliasFrom !== void 0 && !V(e.aliasFrom) || e.coverage.state === "complete" && (e.source !== "history" || !e.leafId) ? !1 : Pt(e) <= n && e.messages.every(Ut) && new Set(e.messages.map((e) => e.id)).size === e.messages.length;
}
function Gt(e) {
	return {
		...e,
		sourceUrl: e.providerId.startsWith("local:") ? R.origin + "/" : R.origin + new URL(e.sourceUrl).pathname,
		messages: e.messages.map((e) => {
			if (!e.activity) return e;
			let { accountDefault: t, quotas: n, ...r } = e.activity;
			return {
				...e,
				activity: {
					...r,
					quotas: []
				}
			};
		})
	};
}
//#endregion
//#region src/runtime/background.ts
var W = chrome.storage.session, G = chrome.storage.local, K = Mt(), Kt = new Set([
	"getSettings",
	"listCollections",
	"listConversations",
	"getConversation",
	"getArchiveRevision",
	"listSaved",
	"listDrafts",
	"storageStatus",
	"makeBackup",
	"previewImport",
	"listJobs",
	"searchPage",
	"lookupConversation"
]), qt = new Set([
	"setSettings",
	"createCollection",
	"updateCollection",
	"saveMessage",
	"updateSaved",
	"deleteSaved",
	"saveDraft",
	"deleteDraft",
	"deleteConversation",
	"setConversationExcluded",
	"clearAll",
	"cleanup",
	"startImport",
	"resumeImport",
	"removeImport"
]), q = (e) => "doc:" + e, J = () => /* @__PURE__ */ Error("This selection is no longer available. Reopen Trace in the source chat.");
async function Jt(e) {
	return (await W.get(e))[e];
}
var Yt = Promise.resolve(), Xt = 0;
function Y(e) {
	let t = Yt.then(e, e);
	return Yt = t.then(() => {}, () => {}), t;
}
var Zt = Promise.all([G.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" }), W.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" })]);
async function Qt(e) {
	if (![
		"adapter-degraded",
		"observer-cap",
		"stream-interrupted",
		"storage-full",
		"cleanup-failed",
		"receiver-unavailable"
	].includes(e)) return;
	let t = (await G.get("diagnostics")).diagnostics, n = Array.isArray(t) ? t : [], r = n.at(-1);
	r?.code === e && Date.now() - r.at < 6e4 ? r.count = Math.min(1e4, r.count + 1) : n.push({
		code: e,
		at: Date.now(),
		count: 1,
		adapter: "chatgpt-web/1"
	}), await G.set({ diagnostics: n.slice(-200) });
}
async function $t(e) {
	if (!B(e) || !V(e.accountId) || !V(e.workspaceId)) return;
	let { salt: t } = await G.get("salt");
	typeof t != "string" && (t = crypto.randomUUID(), await G.set({ salt: t }));
	let n = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(JSON.stringify([
		t,
		e.accountId,
		e.workspaceId
	])));
	return Array.from(new Uint8Array(n), (e) => e.toString(16).padStart(2, "0")).join("");
}
var X = (e) => ({
	tabId: e.tabId,
	documentId: e.documentId,
	epoch: e.epoch
});
function en(e) {
	return {
		...X(e),
		instance: e.instance,
		providerId: e.providerId,
		selectionId: e.selectionId
	};
}
function tn(e) {
	return {
		...X(e),
		providerId: e.providerId,
		selectionId: e.selectionId,
		ordinary: e.temporary === "ordinary" || e.temporary === "unknown" && e.manualOrdinary === !0,
		collectionId: e.collectionId,
		scopeKey: e.scopeKey
	};
}
async function Z(e) {
	return e === void 0 ? void 0 : Jt(q(e));
}
async function Q(e) {
	try {
		let t = await chrome.tabs.sendMessage(e.tabId, {
			v: 1,
			op: "trace-who"
		}, { frameId: 0 });
		if (t?.instance !== e.instance || !H(t.context, e) || "temporary" in e && t.context?.temporary !== e.temporary) throw J();
	} catch {
		throw J();
	}
}
async function nn(e, t, n = !1) {
	let r = await Z(e.tab?.id);
	if (!r || r.documentId !== e.documentId || r.instance !== t.instance || !Ft(t.context) || !H(r, t.context)) throw J();
	return n && await Q(r), r;
}
async function rn(e, t, n) {
	let r = t.tab.id, i = q(r), a = await Z(r);
	if (!V(n.instance) || !Number.isSafeInteger(n.sequence) || Number(n.sequence) < 1 || a !== void 0 && a.documentId === t.documentId && (a.instance !== n.instance || a.sequence >= Number(n.sequence))) throw J();
	let o = await chrome.tabs.sendMessage(r, {
		v: 1,
		op: "trace-who"
	}, { frameId: 0 }).catch(() => null);
	if (o?.instance !== n.instance) throw J();
	let s = n.scope;
	if (!Ft(s) || !B(s) || !H(s, o.context) || !Lt(n.href, s.providerId) || ![
		"ordinary",
		"temporary",
		"unknown"
	].includes(String(s.temporary))) {
		a && await e.removeBinding(a.documentId, a.epoch, a.tabId), await W.remove(i);
		return;
	}
	let c = await $t(s.identity);
	if (a !== void 0 && a.documentId === t.documentId && (s.epoch < a.epoch || s.epoch === a.epoch && (a.providerId !== s.providerId || a.scopeKey !== c) && a.scopeKey !== void 0)) throw J();
	a && (a.documentId !== t.documentId || a.epoch !== s.epoch) && await e.removeBinding(a.documentId, a.epoch, r);
	let l = a !== void 0 && a.documentId === t.documentId && a.scopeKey === c, u = l ? a.collectionId : null, d = a !== void 0 && a.documentId === t.documentId && (!!a.blocked || !l && !!a.scopeKey);
	!d && c && (!l || !u) && (u = (await e.listCollections()).find((e) => e.scopeKey === c && e.autoConsent)?.id ?? null);
	let f = {
		epoch: s.epoch,
		selectionId: s.selectionId,
		providerId: s.providerId,
		temporary: s.temporary,
		manualOrdinary: s.temporary === "unknown" && l && a.epoch === s.epoch && a.providerId === s.providerId && a.manualOrdinary === !0,
		aliasCandidate: l && a.providerId.startsWith("local:") && !s.providerId.startsWith("local:") ? a.providerId : l && a.providerId === s.providerId ? a.aliasCandidate : void 0,
		tabId: r,
		documentId: t.documentId,
		instance: n.instance,
		sequence: Number(n.sequence),
		collectionId: u,
		scopeKey: c,
		blocked: d
	};
	await e.setBinding(tn(f)), await W.set({ [i]: f });
}
async function an() {
	let e = await Jt("stages") ?? {};
	for (let [t, n] of Object.entries(e)) n.expiresAt <= Date.now() && delete e[t];
	return e;
}
async function on(e, t, n) {
	let r = chrome.runtime.getURL("library.html#" + e);
	if (!n && e === "library") {
		let e = await Jt("libraryTab");
		if (e !== void 0) {
			let n = await chrome.tabs.get(e).catch(() => null);
			if (n?.url === r) return await W.set({ ["target:" + e]: t ? en(t) : null }), await chrome.tabs.update(e, { active: !0 }), await chrome.windows.update(n.windowId, { focused: !0 }), e;
		}
	}
	let i = await chrome.tabs.create({ url: r });
	if (i.id === void 0) throw Error("Could not open the extension page.");
	return await W.set({
		["target:" + i.id]: t ? en(t) : null,
		...e === "library" && { libraryTab: i.id }
	}), i.id;
}
async function sn(e, t) {
	if (![
		"save",
		"save-message",
		"export",
		"handoff"
	].includes(String(t.action)) || !Wt(t.projection, e, 2097152)) throw Error("Selection unavailable or too large. Select fewer messages.");
	if (t.projection.aliasFrom && t.projection.aliasFrom !== e.aliasCandidate || t.messageId !== void 0 && (!V(t.messageId) || t.projection.messages.length !== 1 || t.projection.messages[0].id !== t.messageId) || t.action === "save-message" && !t.messageId) throw J();
	let n = Date.now(), r = {
		id: crypto.randomUUID(),
		action: t.action,
		projection: Gt(t.projection),
		createdAt: n,
		expiresAt: n + Nt,
		target: en(e),
		boundCollectionId: e.collectionId,
		...t.messageId ? { messageId: String(t.messageId) } : {}
	}, i = await an();
	if (i[r.id] = r, Pt(i) > 2097152) throw Error("The temporary selections exceed 2 MiB. Close existing reviews or select fewer messages.");
	return r.ownerTab = await on("stage/" + r.id, e, r), await W.set({ stages: i }), { opened: !0 };
}
async function cn(e, t) {
	let n = await an(), r = V(t.id) ? n[t.id] : void 0;
	if (!r || r.ownerTab !== e.tab?.id || r.consumer && r.consumer !== e.documentId) throw Error("This review expired. Open it again from the source chat.");
	let i = await Z(r.target.tabId);
	if (!i || i.documentId !== r.target.documentId || !H(i, r.target) || i.collectionId !== r.boundCollectionId) throw J();
	return await Q(r.target), {
		stages: n,
		stage: r,
		current: i
	};
}
async function ln(e) {
	let t = await Jt("target:" + e.tab?.id);
	if (!t) return null;
	let n = await Z(t.tabId);
	if (!n || n.documentId !== t.documentId || !H(n, t)) return null;
	try {
		await Q(n);
	} catch {
		return null;
	}
	return n;
}
async function $(e = !1) {
	let t = await W.get(null), n = Object.entries(t).filter(([e]) => e.startsWith("doc:")).map(([, e]) => chrome.tabs.sendMessage(e.tabId, {
		v: 1,
		op: "trace-policy"
	}, { documentId: e.documentId }).catch(() => {}));
	n.push(chrome.runtime.sendMessage({
		v: 1,
		event: e ? "archive-cleared" : "archive-changed"
	}).catch(() => {})), await Promise.all(n);
}
async function un() {
	let [e] = await chrome.tabs.query({
		active: !0,
		lastFocusedWindow: !0
	}), t = await Z(e?.id);
	return !t || e?.incognito ? null : (await Q(t), t);
}
async function dn(e, t, n, r) {
	await Zt;
	let i = Rt(n);
	if (!i) throw Error("Unsupported sender.");
	let a = await K, o = B(t) ? t : {};
	if (i === "content") {
		if (e === "scope") return rn(a, n, o);
		if (e === "diagnostic") return Qt(String(o.code));
		if (e === "open" && (o.action === "library" || o.action === "settings")) {
			let e = Ft(o.context) ? await nn(n, o, !0) : void 0;
			return await on(o.action, e), !0;
		}
		let t = await nn(n, o);
		if (e === "status") {
			let e = await a.getCaptureStatus({
				...X(t),
				collectionId: t.collectionId
			}, t.providerId);
			return e.paused = !!t.collectionId && await a.isProviderExcluded(t.collectionId, t.providerId), {
				status: e,
				confirmedOrdinary: t.manualOrdinary === !0,
				alertEnabled: (await a.getSettings()).contextAlert
			};
		}
		if (e === "capture") {
			if (r !== Xt || (await Q(t), r !== Xt) || t.temporary !== "ordinary" && !(t.temporary === "unknown" && t.manualOrdinary) || !Wt(o.projection, t, 131072) || !Number.isSafeInteger(o.generation) || o.projection.aliasFrom && o.projection.aliasFrom !== t.aliasCandidate) throw J();
			return a.capture(Gt(o.projection), {
				...X(t),
				collectionId: t.collectionId,
				generation: Number(o.generation)
			});
		}
		if (e === "stage") return await Q(t), sn(t, o);
		if (e === "togglePause" && t.collectionId) {
			await Q(t);
			let e = await a.isProviderExcluded(t.collectionId, t.providerId);
			return await a.setProviderExcluded(t.collectionId, t.providerId, !e), await $(), !0;
		}
		throw Error("Unsupported action.");
	}
	if (i === "popup") {
		if (e === "popupContext") {
			let e = await un().catch(() => null);
			if (!e) return {};
			let t = await chrome.tabs.sendMessage(e.tabId, {
				v: 1,
				op: "trace-popup"
			}, { documentId: e.documentId });
			return t?.instance !== e.instance || !H(e, t.context) || !Ht(t.activity) ? {} : {
				context: {
					epoch: e.epoch,
					providerId: e.providerId,
					selectionId: e.selectionId
				},
				activity: t.activity,
				documentId: e.documentId,
				tabId: e.tabId,
				theme: t.theme === "dark" ? "dark" : "light",
				alertEnabled: !!t.alertEnabled
			};
		}
		if (e === "popupAction") {
			if (o.action === "library" || o.action === "settings") return await on(o.action, await un().catch(() => null) ?? void 0), !0;
			let e = await un();
			if (!e || !Ft(o.context) || !H(e, o.context) || e.tabId !== o.tabId || e.documentId !== o.documentId) throw J();
			if (o.action === "pause" && e.collectionId) {
				let t = await a.isProviderExcluded(e.collectionId, e.providerId);
				return await a.setProviderExcluded(e.collectionId, e.providerId, !t), await $(), !0;
			}
			if (![
				"save",
				"export",
				"handoff"
			].includes(String(o.action))) throw J();
			let t = await chrome.tabs.sendMessage(e.tabId, {
				v: 1,
				op: "trace-snapshot",
				instance: e.instance,
				context: o.context
			}, { documentId: e.documentId });
			if (t?.instance !== e.instance || !H(t.context, e)) throw J();
			return sn(e, {
				...o,
				projection: t.projection
			});
		}
		throw Error("Unsupported popup action.");
	}
	if (e === "readStage" || e === "saveStage") {
		let { stages: t, stage: r, current: i } = await cn(n, o);
		if (e === "readStage") {
			if (r.read) throw Error("This temporary selection has already been opened.");
			r.consumer = n.documentId, r.read = !0, (r.action === "export" || r.action === "handoff") && delete t[r.id], await W.set({ stages: t });
			let { target: e, ownerTab: i, consumer: a, read: o, boundCollectionId: s, ...c } = r;
			return c;
		}
		if (!r.read || r.consumer !== n.documentId || !["save", "save-message"].includes(r.action) || !V(o.collectionId)) throw J();
		let s = (await a.listCollections()).find((e) => e.id === o.collectionId);
		if (!s || s.scopeKey && i.scopeKey !== s.scopeKey) throw Error("Choose a destination collection that matches this source.");
		if (o.selectedMessageIds !== void 0 && (!Array.isArray(o.selectedMessageIds) || !o.selectedMessageIds.length || !o.selectedMessageIds.every((e) => V(e) && r.projection.messages.some((t) => t.id === e)))) throw J();
		let c = o.selectedMessageIds;
		if (r.action === "save-message" && (!r.messageId || c && (c.length !== 1 || c[0] !== r.messageId))) throw J();
		let l;
		if (o.savedItem !== void 0) {
			if (!B(o.savedItem) || !c?.length) throw J();
			let { label: e, tags: t, note: n } = o.savedItem;
			if (e !== void 0 && (typeof e != "string" || e.length > 256) || n !== void 0 && (typeof n != "string" || n.length > 16384) || t !== void 0 && (!Array.isArray(t) || t.length > 32 || !t.every((e) => z(e, 128)))) throw Error("Invalid note or tags.");
			l = {
				label: e,
				note: n,
				tags: t
			};
		}
		r.action === "save-message" && !l && (l = {});
		let u = await a.saveCapture(r.projection, {
			...X(i),
			collectionId: s.id,
			expiresAt: r.expiresAt,
			intentId: r.id,
			generation: (await a.getSettings()).generation
		}, c ?? (r.messageId ? [r.messageId] : void 0), l);
		return delete t[r.id], await W.set({ stages: t }), await $(), u;
	}
	if (e === "getTarget" || e === "bindTarget" || e === "resumeTarget" || e === "setTargetPause" || e === "confirmOrdinary") {
		let t = await ln(n);
		if (e === "getTarget") {
			if (!t) return null;
			let e = await a.getCaptureStatus({
				...X(t),
				collectionId: t.collectionId
			}, t.providerId);
			return {
				...X(t),
				providerId: t.providerId,
				temporary: t.temporary,
				identityObserved: !!t.scopeKey,
				boundCollectionId: t.collectionId,
				paused: e.paused,
				manualOrdinary: t.manualOrdinary === !0
			};
		}
		if (!t) throw Error("Open Settings from the source conversation to choose a collection.");
		if (e === "bindTarget") {
			let e = (await a.listCollections()).find((e) => e.id === o.collectionId);
			if (!e || e.scopeKey && e.scopeKey !== t.scopeKey) throw Error("Choose a collection for the current account and workspace.");
			t.scopeKey && !e.scopeKey && o.observed === !0 && await a.bindObservedCollection(e.id, t.scopeKey), t.collectionId = e.id, t.blocked = !1, await a.setBinding(tn(t)), await W.set({ [q(t.tabId)]: t });
		} else if (e === "confirmOrdinary") {
			if (t.temporary !== "unknown" || !t.collectionId || typeof o.confirmed != "boolean") throw J();
			t.manualOrdinary = o.confirmed, await a.setBinding(tn(t)), await W.set({ [q(t.tabId)]: t });
		} else {
			if (!t.collectionId || e === "setTargetPause" && typeof o.paused != "boolean") throw J();
			await a.setProviderExcluded(t.collectionId, t.providerId, e === "setTargetPause" && o.paused === !0);
		}
		return await $(), !0;
	}
	if (e === "diagnostics") return (await G.get("diagnostics")).diagnostics ?? [];
	if (e === "clearDiagnostics") return await G.remove("diagnostics"), !0;
	if (e === "getTheme") {
		let e = await ln(n);
		if (!e) return null;
		let t = await chrome.tabs.sendMessage(e.tabId, {
			v: 1,
			op: "trace-theme"
		}, { documentId: e.documentId }).catch(() => null);
		return !t || typeof t.dark != "boolean" ? null : {
			dark: t.dark,
			...typeof t.fontFamily == "string" && /^[\w\s,"'-]{1,180}$/.test(t.fontFamily) && { fontFamily: t.fontFamily }
		};
	}
	if (!Kt.has(e) && !qt.has(e)) throw Error("Unsupported library operation.");
	let s = t === void 0 ? [] : t;
	if (!Array.isArray(s) || s.length > 5) throw Error("Invalid archive operation.");
	if (e === "clearAll") {
		let e = await W.get(null);
		await a.setSettings({ autoCapture: !1 }), await $(!0), await W.clear(), await G.clear(), await a.clearAll();
		for (let [t, n] of Object.entries(e)) t.startsWith("doc:") && chrome.tabs.sendMessage(n.tabId, {
			v: 1,
			op: "trace-reconnect"
		}, { documentId: n.documentId }).catch(() => {});
		return await chrome.runtime.sendMessage({
			v: 1,
			event: "archive-cleared"
		}).catch(() => {}), !0;
	}
	let c = a[e];
	if (typeof c != "function") throw Error("Unsupported archive operation.");
	let l = e === "deleteConversation" && V(s[0]) ? await a.getConversation(s[0]) : null, u = await c.apply(a, s);
	if (qt.has(e) && e !== "cleanup") {
		if (e === "deleteConversation" || e === "setSettings" || e === "updateCollection" || e === "removeImport") if (e === "deleteConversation") {
			let e = l?.conversation.providerId, t = await an();
			for (let [n, r] of Object.entries(t)) e && r.projection.providerId === e && delete t[n];
			await W.set({ stages: t }), await chrome.runtime.sendMessage({
				v: 1,
				event: "archive-chat-deleted",
				conversationId: s[0],
				providerId: e,
				sourceUrl: l?.conversation.sourceUrl
			}).catch(() => {});
		} else e === "removeImport" && (await W.remove("stages"), await chrome.runtime.sendMessage({
			v: 1,
			event: "archive-import-removed"
		}).catch(() => {}));
		await $();
	}
	return u;
}
chrome.runtime.onMessage.addListener((e, t, n) => {
	if (!B(e) || e.v !== 1 || !z(e.op, 64) || !Rt(t)) return !1;
	let r = e.op, i = Array.isArray(e.args) ? e.args[0] : void 0, a = Rt(t) === "library" && (r === "clearAll" || r === "setSettings" && B(i) && i.autoCapture === !1);
	a && Xt++;
	let o = Xt, s = a ? K.then((e) => e.setSettings({ autoCapture: !1 })) : Promise.resolve();
	return s.catch(() => {}), Y(async () => (await s, dn(r, e.args, t, o))).then((e) => n({
		ok: !0,
		data: e
	}), async (e) => {
		(e instanceof DOMException && e.name === "QuotaExceededError" || e instanceof Error && e.message === "Local storage is full. Automatic saving is paused.") && await Y(async () => {
			await (await K).setSettings({ autoCapture: !1 }), await Qt("storage-full"), await $();
		}).catch(() => {}), n({
			ok: !1,
			error: e instanceof Error && !(e instanceof DOMException) ? e.message.slice(0, 220) : "The operation could not complete. Existing data was kept."
		});
	}), !0;
});
async function fn() {
	let e = await K, t = await an();
	await W.set({ stages: t }), await e.cleanup();
}
chrome.alarms.onAlarm.addListener((e) => {
	e.name === "retention" && Y(fn).catch(() => Qt("cleanup-failed"));
});
async function pn() {
	await chrome.alarms.get("retention") || await chrome.alarms.create("retention", { periodInMinutes: 15 });
}
chrome.runtime.onInstalled.addListener((e) => {
	Y(async () => {
		await Zt, await pn(), await fn(), e.reason === "install" && !(await (await K).getSettings()).welcomeComplete && await on("welcome");
	});
}), chrome.runtime.onStartup.addListener(() => {
	Y(async () => {
		await Zt, await pn(), await (await K).resetFences(), await fn();
	});
}), chrome.tabs.onRemoved.addListener((e) => {
	Y(async () => {
		let t = await Z(e);
		t && await (await K).removeBinding(t.documentId, t.epoch, e);
		let n = await an();
		for (let [t, r] of Object.entries(n)) (r.ownerTab === e || r.target.tabId === e) && delete n[t];
		await W.set({ stages: n }), await W.remove([q(e), "target:" + e]);
	});
}), chrome.commands.onCommand.addListener((e) => {
	Y(async () => {
		let t = await un().catch(() => null);
		if (e === "open-library") {
			await on("library", t ?? void 0);
			return;
		}
		e === "show-activity" && t && await chrome.tabs.sendMessage(t.tabId, {
			v: 1,
			op: "trace-activity",
			instance: t.instance,
			context: t
		}, { documentId: t.documentId });
	});
});
//#endregion
